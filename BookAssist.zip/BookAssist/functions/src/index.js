// functions/src/index.js
// Firebase Cloud Functions — deployed for Live Mode SMS
// Uses Semaphore (Philippines) or Twilio for real SMS

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const axios = require('axios');

admin.initializeApp();

/**
 * Sends booking confirmation SMS to driver and customer.
 * Called by app in Live Mode when a booking is confirmed.
 *
 * To use Semaphore (recommended for PH numbers):
 *   1. Sign up at https://semaphore.co
 *   2. Set your API key: firebase functions:config:set semaphore.api_key="YOUR_KEY"
 *
 * To use Twilio:
 *   1. Sign up at https://twilio.com
 *   2. Set config: firebase functions:config:set twilio.account_sid="X" twilio.auth_token="Y" twilio.from="+1..."
 */
exports.sendBookingConfirmation = functions
  .region('asia-southeast1')
  .https.onCall(async (data, context) => {
    // Auth check
    if (!context.auth) {
      throw new functions.https.HttpsError('unauthenticated', 'Must be authenticated.');
    }

    const { bookingId, driverPhone, customerPhone, driverMessage, customerMessage } = data;

    if (!bookingId || !driverMessage || !customerMessage) {
      throw new functions.https.HttpsError('invalid-argument', 'Missing required fields.');
    }

    const config = functions.config();

    // ─── Semaphore (PH) ──────────────────────────────────────────
    const useSemaphore = !!config.semaphore?.api_key;

    if (useSemaphore) {
      const sendSemaphoreSms = async (to, message) => {
        const payload = new URLSearchParams({
          apikey: config.semaphore.api_key,
          number: to.replace(/\D/g, ''), // strip non-digits
          message,
          sendername: config.semaphore.sender_name || 'BookAssist',
        });

        const response = await axios.post(
          'https://api.semaphore.co/api/v4/messages',
          payload.toString(),
          { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
        );
        return response.data;
      };

      const results = await Promise.allSettled([
        driverPhone ? sendSemaphoreSms(driverPhone, driverMessage) : Promise.resolve(null),
        sendSemaphoreSms(customerPhone, customerMessage),
      ]);

      // Log to Firestore
      await admin.firestore().collection('sms_logs').add({
        bookingId,
        driverResult: results[0].status,
        customerResult: results[1].status,
        sentAt: admin.firestore.FieldValue.serverTimestamp(),
      });

      return { success: true, provider: 'semaphore' };
    }

    // ─── Twilio (International) ──────────────────────────────────
    const useTwilio = !!config.twilio?.account_sid;

    if (useTwilio) {
      const twilio = require('twilio')(config.twilio.account_sid, config.twilio.auth_token);

      const sendTwilioSms = async (to, body) => {
        return twilio.messages.create({
          from: config.twilio.from,
          to,
          body,
        });
      };

      await Promise.allSettled([
        driverPhone ? sendTwilioSms(driverPhone, driverMessage) : Promise.resolve(null),
        sendTwilioSms(customerPhone, customerMessage),
      ]);

      return { success: true, provider: 'twilio' };
    }

    // ─── No provider configured ──────────────────────────────────
    functions.logger.warn('No SMS provider configured. Set semaphore or twilio config.');
    return { success: false, reason: 'No SMS provider configured.' };
  });
