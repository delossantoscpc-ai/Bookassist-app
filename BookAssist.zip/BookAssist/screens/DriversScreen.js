// screens/DriversScreen.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  RefreshControl,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import { fetchDrivers, updateDriver } from '../services/dataService';
import AppHeader from '../components/AppHeader';
import StatusBadge from '../components/StatusBadge';
import EmptyState from '../components/EmptyState';
import LoadingScreen from '../components/LoadingScreen';
import { Colors, Spacing, Radii, FontSize } from '../utils/theme';
import { DRIVER_STATUS_COLORS, DRIVER_STATUS_LABELS } from '../mock/drivers';

export default function DriversScreen({ navigation }) {
  const { isDemoMode, user } = useApp();
  const [drivers, setDrivers] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  const load = useCallback(async () => {
    const data = await fetchDrivers(isDemoMode, user.companyId);
    setDrivers(data);
    setLoading(false);
    setRefreshing(false);
  }, [isDemoMode, user?.companyId]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    let result = drivers;
    if (filterStatus !== 'all') result = result.filter(d => d.status === filterStatus);
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        d =>
          d.firstName?.toLowerCase().includes(q) ||
          d.lastName?.toLowerCase().includes(q) ||
          d.phone?.includes(q)
      );
    }
    setFiltered(result);
  }, [drivers, filterStatus, search]);

  const handleStatusChange = (driver) => {
    Alert.alert(
      `${driver.firstName} ${driver.lastName}`,
      'Update driver status:',
      ['available', 'off_duty', 'inactive'].map(s => ({
        text: DRIVER_STATUS_LABELS[s],
        onPress: async () => {
          await updateDriver(isDemoMode, driver.id, { status: s });
          setDrivers(prev => prev.map(d => d.id === driver.id ? { ...d, status: s } : d));
        },
      })).concat([{ text: 'Cancel', style: 'cancel' }])
    );
  };

  if (loading) return <LoadingScreen message="Loading drivers..." />;

  const renderDriver = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <View style={[styles.avatar, { backgroundColor: DRIVER_STATUS_COLORS[item.status] + '22' }]}>
          <Text style={styles.avatarText}>
            {item.firstName?.[0]}{item.lastName?.[0]}
          </Text>
        </View>
        <View style={styles.info}>
          <Text style={styles.name}>{item.firstName} {item.lastName}</Text>
          <Text style={styles.phone}>{item.phone}</Text>
          <View style={styles.ratingRow}>
            <Ionicons name="star" size={12} color={Colors.warning} />
            <Text style={styles.rating}>{item.rating}</Text>
            <Text style={styles.trips}>· {item.totalTrips} trips</Text>
          </View>
        </View>
        <StatusBadge label={DRIVER_STATUS_LABELS[item.status]} color={DRIVER_STATUS_COLORS[item.status]} />
      </View>

      <View style={styles.details}>
        <View style={styles.detail}>
          <Ionicons name="card" size={12} color={Colors.textMuted} />
          <Text style={styles.detailText}>{item.licenseNumber}</Text>
        </View>
        <View style={styles.detail}>
          <Ionicons name="calendar" size={12} color={Colors.textMuted} />
          <Text style={styles.detailText}>Exp: {item.licenseExpiry}</Text>
        </View>
        <View style={styles.detail}>
          <Ionicons name="location" size={12} color={Colors.textMuted} />
          <Text style={styles.detailText}>{item.address}</Text>
        </View>
      </View>

      {item.notes && (
        <View style={styles.notes}>
          <Ionicons name="information-circle" size={12} color={Colors.textMuted} />
          <Text style={styles.notesText}>{item.notes}</Text>
        </View>
      )}

      <View style={styles.cardActions}>
        <TouchableOpacity style={styles.actionBtn} onPress={() => handleStatusChange(item)}>
          <Ionicons name="swap-horizontal" size={14} color={Colors.accent} />
          <Text style={styles.actionBtnText}>Status</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.actionBtn}>
          <Ionicons name="call" size={14} color={Colors.success} />
          <Text style={[styles.actionBtnText, { color: Colors.success }]}>Call</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <AppHeader />

      <View style={styles.searchRow}>
        <Ionicons name="search" size={16} color={Colors.textMuted} />
        <TextInput
          style={styles.searchInput}
          value={search}
          onChangeText={setSearch}
          placeholder="Search drivers..."
          placeholderTextColor={Colors.textMuted}
        />
      </View>

      <FlatList
        data={['all', 'available', 'on_trip', 'off_duty', 'inactive']}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filters}
        keyExtractor={i => i}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.filterTab, filterStatus === item && styles.filterTabActive]}
            onPress={() => setFilterStatus(item)}
          >
            <Text style={[styles.filterText, filterStatus === item && styles.filterTextActive]}>
              {item === 'all' ? 'All' : DRIVER_STATUS_LABELS[item]}
            </Text>
          </TouchableOpacity>
        )}
        style={styles.filterList}
      />

      <Text style={styles.countText}>{filtered.length} driver{filtered.length !== 1 ? 's' : ''}</Text>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        renderItem={renderDriver}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={Colors.accent} />
        }
        ListEmptyComponent={
          <EmptyState icon="person" title="No Drivers Found" subtitle="No drivers match your filter." />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    margin: Spacing.base,
    borderRadius: Radii.lg,
    paddingHorizontal: Spacing.md,
    height: 44,
    gap: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  searchInput: { flex: 1, color: Colors.textPrimary, fontSize: FontSize.sm },
  filterList: { marginBottom: Spacing.xs },
  filters: { paddingHorizontal: Spacing.base, gap: Spacing.sm },
  filterTab: { paddingHorizontal: Spacing.md, paddingVertical: Spacing.xs, borderRadius: Radii.full, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border },
  filterTabActive: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  filterText: { color: Colors.textSecondary, fontSize: FontSize.xs, fontWeight: '600' },
  filterTextActive: { color: Colors.white },
  countText: { color: Colors.textMuted, fontSize: FontSize.xs, paddingHorizontal: Spacing.base, paddingVertical: Spacing.xs },
  list: { padding: Spacing.base, gap: Spacing.sm, paddingBottom: 80 },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.base,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.sm,
  },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  info: { flex: 1 },
  name: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  phone: { color: Colors.textSecondary, fontSize: FontSize.xs },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 2 },
  rating: { color: Colors.warning, fontSize: FontSize.xs, fontWeight: '700' },
  trips: { color: Colors.textMuted, fontSize: FontSize.xs },
  details: { gap: Spacing.xs },
  detail: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  detailText: { color: Colors.textSecondary, fontSize: FontSize.xs },
  notes: { flexDirection: 'row', gap: Spacing.xs, backgroundColor: Colors.dark, borderRadius: Radii.md, padding: Spacing.sm },
  notesText: { color: Colors.textMuted, fontSize: FontSize.xs, flex: 1, lineHeight: 16 },
  cardActions: {
    flexDirection: 'row',
    gap: Spacing.sm,
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  actionBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.xs,
    backgroundColor: Colors.accent + '15',
    paddingVertical: Spacing.sm,
    borderRadius: Radii.md,
    borderWidth: 1,
    borderColor: Colors.accent + '40',
  },
  actionBtnText: { color: Colors.accent, fontSize: FontSize.xs, fontWeight: '600' },
});
