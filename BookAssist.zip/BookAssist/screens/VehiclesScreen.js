// screens/VehiclesScreen.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  RefreshControl,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import { fetchVehicles, updateVehicle } from '../services/dataService';
import AppHeader from '../components/AppHeader';
import StatusBadge from '../components/StatusBadge';
import EmptyState from '../components/EmptyState';
import LoadingScreen from '../components/LoadingScreen';
import {
  Colors,
  Spacing,
  Radii,
  FontSize,
  formatCurrency,
} from '../utils/theme';
import {
  VEHICLE_STATUS_COLORS,
  VEHICLE_STATUS_LABELS,
} from '../mock/vehicles';

const VEHICLE_ICONS = { SUV: 'car-sport', Sedan: 'car', Van: 'bus', Pickup: 'car' };

export default function VehiclesScreen({ navigation }) {
  const { isDemoMode, user } = useApp();
  const [vehicles, setVehicles] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  const load = useCallback(async () => {
    const data = await fetchVehicles(isDemoMode, user.companyId);
    setVehicles(data);
    setLoading(false);
    setRefreshing(false);
  }, [isDemoMode, user?.companyId]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    let result = vehicles;
    if (filterStatus !== 'all') result = result.filter(v => v.status === filterStatus);
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        v =>
          v.make?.toLowerCase().includes(q) ||
          v.model?.toLowerCase().includes(q) ||
          v.plate?.toLowerCase().includes(q) ||
          v.type?.toLowerCase().includes(q)
      );
    }
    setFiltered(result);
  }, [vehicles, filterStatus, search]);

  const handleStatusChange = (vehicle) => {
    const statuses = ['available', 'maintenance', 'reserved'];
    Alert.alert(
      `${vehicle.make} ${vehicle.model}`,
      'Update vehicle status:',
      statuses.map(s => ({
        text: VEHICLE_STATUS_LABELS[s],
        onPress: async () => {
          await updateVehicle(isDemoMode, vehicle.id, { status: s });
          setVehicles(prev =>
            prev.map(v => v.id === vehicle.id ? { ...v, status: s } : v)
          );
        },
      })).concat([{ text: 'Cancel', style: 'cancel' }])
    );
  };

  if (loading) return <LoadingScreen message="Loading vehicles..." />;

  const renderVehicle = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <View style={[styles.typeIcon, { backgroundColor: VEHICLE_STATUS_COLORS[item.status] + '22' }]}>
          <Ionicons
            name={VEHICLE_ICONS[item.type] || 'car'}
            size={24}
            color={VEHICLE_STATUS_COLORS[item.status]}
          />
        </View>
        <View style={styles.info}>
          <Text style={styles.vehicleName}>{item.make} {item.model}</Text>
          <Text style={styles.vehicleSub}>{item.year} · {item.color} · {item.type}</Text>
          <Text style={styles.plate}>{item.plate}</Text>
        </View>
        <StatusBadge
          label={VEHICLE_STATUS_LABELS[item.status]}
          color={VEHICLE_STATUS_COLORS[item.status]}
        />
      </View>

      <View style={styles.stats}>
        <View style={styles.stat}>
          <Ionicons name="people" size={12} color={Colors.textMuted} />
          <Text style={styles.statText}>{item.seats} seats</Text>
        </View>
        <View style={styles.stat}>
          <Ionicons name="settings" size={12} color={Colors.textMuted} />
          <Text style={styles.statText}>{item.transmission}</Text>
        </View>
        <View style={styles.stat}>
          <Ionicons name="water" size={12} color={Colors.textMuted} />
          <Text style={styles.statText}>{item.fuelType}</Text>
        </View>
        <View style={styles.stat}>
          <Ionicons name="speedometer" size={12} color={Colors.textMuted} />
          <Text style={styles.statText}>{item.mileage?.toLocaleString()} km</Text>
        </View>
      </View>

      {item.features?.length > 0 && (
        <View style={styles.features}>
          {item.features.map(f => (
            <View key={f} style={styles.featureTag}>
              <Text style={styles.featureText}>{f}</Text>
            </View>
          ))}
        </View>
      )}

      <View style={styles.cardBottom}>
        <Text style={styles.rate}>{formatCurrency(item.dailyRate)}<Text style={styles.rateUnit}>/day</Text></Text>
        <TouchableOpacity
          style={styles.statusBtn}
          onPress={() => handleStatusChange(item)}
        >
          <Ionicons name="swap-horizontal" size={14} color={Colors.accent} />
          <Text style={styles.statusBtnText}>Update Status</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <AppHeader />

      <View style={styles.searchRow}>
        <Ionicons name="search" size={16} color={Colors.textMuted} />
        <TextInput
          style={styles.searchInput}
          value={search}
          onChangeText={setSearch}
          placeholder="Search vehicles..."
          placeholderTextColor={Colors.textMuted}
        />
      </View>

      <FlatList
        data={['all', 'available', 'on_trip', 'maintenance', 'reserved']}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filters}
        keyExtractor={i => i}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.filterTab, filterStatus === item && styles.filterTabActive]}
            onPress={() => setFilterStatus(item)}
          >
            <Text style={[styles.filterText, filterStatus === item && styles.filterTextActive]}>
              {item === 'all' ? 'All' : VEHICLE_STATUS_LABELS[item]}
            </Text>
          </TouchableOpacity>
        )}
        style={styles.filterList}
      />

      <Text style={styles.countText}>{filtered.length} vehicle{filtered.length !== 1 ? 's' : ''}</Text>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        renderItem={renderVehicle}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={Colors.accent} />
        }
        ListEmptyComponent={
          <EmptyState icon="car" title="No Vehicles Found" subtitle="No vehicles match your filter." />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    margin: Spacing.base,
    borderRadius: Radii.lg,
    paddingHorizontal: Spacing.md,
    height: 44,
    gap: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  searchInput: { flex: 1, color: Colors.textPrimary, fontSize: FontSize.sm },
  filterList: { marginBottom: Spacing.xs },
  filters: { paddingHorizontal: Spacing.base, gap: Spacing.sm },
  filterTab: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radii.full,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  filterTabActive: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  filterText: { color: Colors.textSecondary, fontSize: FontSize.xs, fontWeight: '600' },
  filterTextActive: { color: Colors.white },
  countText: { color: Colors.textMuted, fontSize: FontSize.xs, paddingHorizontal: Spacing.base, paddingVertical: Spacing.xs },
  list: { padding: Spacing.base, gap: Spacing.sm, paddingBottom: 80 },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.base,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.sm,
  },
  cardTop: { flexDirection: 'row', alignItems: 'flex-start', gap: Spacing.md },
  typeIcon: {
    width: 48,
    height: 48,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  info: { flex: 1 },
  vehicleName: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  vehicleSub: { color: Colors.textSecondary, fontSize: FontSize.xs },
  plate: {
    color: Colors.accent,
    fontSize: FontSize.xs,
    fontWeight: '700',
    backgroundColor: Colors.accent + '15',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
    alignSelf: 'flex-start',
    marginTop: 3,
  },
  stats: { flexDirection: 'row', gap: Spacing.base, flexWrap: 'wrap' },
  stat: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statText: { color: Colors.textMuted, fontSize: FontSize.xs },
  features: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs },
  featureTag: {
    backgroundColor: Colors.dark,
    borderRadius: Radii.sm,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  featureText: { color: Colors.textSecondary, fontSize: 10 },
  cardBottom: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  rate: { color: Colors.textPrimary, fontSize: FontSize.lg, fontWeight: '800' },
  rateUnit: { color: Colors.textMuted, fontSize: FontSize.xs, fontWeight: '400' },
  statusBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: Colors.accent + '15',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radii.full,
    borderWidth: 1,
    borderColor: Colors.accent + '40',
  },
  statusBtnText: { color: Colors.accent, fontSize: FontSize.xs, fontWeight: '600' },
});
