// screens/NewBookingScreen.js
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import {
  createBooking,
  fetchVehicles,
  fetchDrivers,
  fetchCustomers,
} from '../services/dataService';
import AppHeader from '../components/AppHeader';
import { Colors, Spacing, Radii, FontSize, Shadow } from '../utils/theme';

const FormInput = ({ label, value, onChangeText, placeholder, keyboardType, multiline }) => (
  <View style={styles.formGroup}>
    <Text style={styles.label}>{label}</Text>
    <TextInput
      style={[styles.input, multiline && styles.textArea]}
      value={value}
      onChangeText={onChangeText}
      placeholder={placeholder}
      placeholderTextColor={Colors.textMuted}
      keyboardType={keyboardType || 'default'}
      multiline={multiline}
      numberOfLines={multiline ? 3 : 1}
    />
  </View>
);

const SelectRow = ({ label, selected, onPress, placeholder, icon }) => (
  <TouchableOpacity style={styles.selectRow} onPress={onPress}>
    <View style={styles.selectLeft}>
      <Ionicons name={icon} size={16} color={Colors.textMuted} />
      <View>
        <Text style={styles.selectLabel}>{label}</Text>
        {selected ? (
          <Text style={styles.selectValue}>{selected}</Text>
        ) : (
          <Text style={styles.selectPlaceholder}>{placeholder}</Text>
        )}
      </View>
    </View>
    <Ionicons name="chevron-forward" size={16} color={Colors.textMuted} />
  </TouchableOpacity>
);

export default function NewBookingScreen({ navigation }) {
  const { isDemoMode, user } = useApp();
  const [saving, setSaving] = useState(false);

  const [vehicles, setVehicles] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [customers, setCustomers] = useState([]);

  const [form, setForm] = useState({
    customerId: '',
    customerName: '',
    customerPhone: '',
    vehicleId: '',
    vehicleName: '',
    vehiclePlate: '',
    driverId: '',
    driverName: '',
    driverPhone: '',
    pickupLocation: '',
    dropoffLocation: '',
    startDate: new Date().toISOString().slice(0, 10),
    endDate: new Date().toISOString().slice(0, 10),
    startTime: '08:00',
    totalDays: '1',
    dailyRate: '',
    discount: '0',
    paymentMethod: 'cash',
    notes: '',
  });

  useEffect(() => {
    const load = async () => {
      const [v, d, c] = await Promise.all([
        fetchVehicles(isDemoMode, user.companyId),
        fetchDrivers(isDemoMode, user.companyId),
        fetchCustomers(isDemoMode, user.companyId),
      ]);
      setVehicles(v.filter(v => v.status === 'available'));
      setDrivers(d.filter(d => d.status === 'available'));
      setCustomers(c);
    };
    load();
  }, []);

  const set = (key) => (val) => setForm(f => ({ ...f, [key]: val }));

  const totalAmount = (parseFloat(form.dailyRate) || 0) * (parseInt(form.totalDays) || 1);
  const finalAmount = totalAmount - (parseFloat(form.discount) || 0);

  const showCustomerPicker = () => {
    Alert.alert(
      'Select Customer',
      '',
      customers.map(c => ({
        text: `${c.firstName} ${c.lastName}`,
        onPress: () => setForm(f => ({
          ...f,
          customerId: c.id,
          customerName: `${c.firstName} ${c.lastName}`,
          customerPhone: c.phone,
        })),
      })).concat([{ text: 'Cancel', style: 'cancel' }])
    );
  };

  const showVehiclePicker = () => {
    Alert.alert(
      'Select Vehicle',
      'Available vehicles:',
      vehicles.map(v => ({
        text: `${v.make} ${v.model} - ${v.plate}`,
        onPress: () => setForm(f => ({
          ...f,
          vehicleId: v.id,
          vehicleName: `${v.make} ${v.model}`,
          vehiclePlate: v.plate,
          dailyRate: String(v.dailyRate),
        })),
      })).concat([{ text: 'Cancel', style: 'cancel' }])
    );
  };

  const showDriverPicker = () => {
    Alert.alert(
      'Select Driver',
      'Available drivers:',
      drivers.map(d => ({
        text: `${d.firstName} ${d.lastName} ⭐${d.rating}`,
        onPress: () => setForm(f => ({
          ...f,
          driverId: d.id,
          driverName: `${d.firstName} ${d.lastName}`,
          driverPhone: d.phone,
        })),
      })).concat([{ text: 'Cancel', style: 'cancel' }])
    );
  };

  const handleSave = async () => {
    if (!form.customerName || !form.pickupLocation || !form.dropoffLocation) {
      Alert.alert('Required Fields', 'Please fill in customer, pickup, and dropoff locations.');
      return;
    }
    setSaving(true);
    try {
      const booking = await createBooking(isDemoMode, {
        ...form,
        companyId: user.companyId,
        totalDays: parseInt(form.totalDays) || 1,
        dailyRate: parseFloat(form.dailyRate) || 0,
        discount: parseFloat(form.discount) || 0,
        totalAmount,
        finalAmount,
      });
      Alert.alert(
        '✅ Booking Created',
        `Booking ${booking.id} created successfully.`,
        [{ text: 'View', onPress: () => navigation.replace('BookingDetail', { bookingId: booking.id }) }]
      );
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.container}>
      <AppHeader title="New Booking" showBack onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Customer */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Customer</Text>
          <SelectRow
            label="Customer"
            icon="person"
            selected={form.customerName}
            placeholder="Select existing customer"
            onPress={showCustomerPicker}
          />
          <View style={styles.divider} />
          <FormInput label="Or enter name manually" value={form.customerName} onChangeText={set('customerName')} placeholder="Customer full name" />
          <FormInput label="Phone" value={form.customerPhone} onChangeText={set('customerPhone')} placeholder="+63 9XX XXX XXXX" keyboardType="phone-pad" />
        </View>

        {/* Vehicle & Driver */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Vehicle & Driver</Text>
          <SelectRow label="Vehicle" icon="car" selected={form.vehicleName ? `${form.vehicleName} (${form.vehiclePlate})` : ''} placeholder="Select available vehicle" onPress={showVehiclePicker} />
          <View style={styles.divider} />
          <SelectRow label="Driver" icon="person-circle" selected={form.driverName} placeholder="Select available driver" onPress={showDriverPicker} />
        </View>

        {/* Trip Details */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Trip Details</Text>
          <FormInput label="Pickup Location" value={form.pickupLocation} onChangeText={set('pickupLocation')} placeholder="e.g. Waterfront Hotel Cebu" />
          <FormInput label="Dropoff Location" value={form.dropoffLocation} onChangeText={set('dropoffLocation')} placeholder="e.g. Oslob, Cebu" />
          <View style={styles.row}>
            <View style={styles.halfField}>
              <FormInput label="Start Date" value={form.startDate} onChangeText={set('startDate')} placeholder="YYYY-MM-DD" />
            </View>
            <View style={styles.halfField}>
              <FormInput label="Time" value={form.startTime} onChangeText={set('startTime')} placeholder="HH:MM" />
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.halfField}>
              <FormInput label="End Date" value={form.endDate} onChangeText={set('endDate')} placeholder="YYYY-MM-DD" />
            </View>
            <View style={styles.halfField}>
              <FormInput label="Days" value={form.totalDays} onChangeText={set('totalDays')} placeholder="1" keyboardType="numeric" />
            </View>
          </View>
        </View>

        {/* Payment */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Payment</Text>
          <FormInput label="Daily Rate (₱)" value={form.dailyRate} onChangeText={set('dailyRate')} placeholder="3500" keyboardType="numeric" />
          <FormInput label="Discount (₱)" value={form.discount} onChangeText={set('discount')} placeholder="0" keyboardType="numeric" />

          <View style={styles.paymentMethods}>
            {['cash', 'card', 'bank_transfer', 'online'].map(method => (
              <TouchableOpacity
                key={method}
                style={[styles.methodBtn, form.paymentMethod === method && styles.methodBtnActive]}
                onPress={() => set('paymentMethod')(method)}
              >
                <Text style={[styles.methodText, form.paymentMethod === method && styles.methodTextActive]}>
                  {method.replace('_', ' ').toUpperCase()}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.totalBox}>
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Subtotal</Text>
              <Text style={styles.totalValue}>₱{totalAmount.toLocaleString()}</Text>
            </View>
            {parseFloat(form.discount) > 0 && (
              <View style={styles.totalRow}>
                <Text style={styles.totalLabel}>Discount</Text>
                <Text style={[styles.totalValue, { color: Colors.success }]}>-₱{parseFloat(form.discount).toLocaleString()}</Text>
              </View>
            )}
            <View style={[styles.totalRow, styles.totalFinalRow]}>
              <Text style={styles.totalFinalLabel}>Total</Text>
              <Text style={styles.totalFinalValue}>₱{finalAmount.toLocaleString()}</Text>
            </View>
          </View>
        </View>

        {/* Notes */}
        <View style={styles.card}>
          <FormInput label="Notes (optional)" value={form.notes} onChangeText={set('notes')} placeholder="Special requests, instructions..." multiline />
        </View>

        {/* Save */}
        <TouchableOpacity
          style={[styles.saveBtn, saving && { opacity: 0.6 }]}
          onPress={handleSave}
          disabled={saving}
        >
          {saving ? (
            <ActivityIndicator color={Colors.white} />
          ) : (
            <>
              <Ionicons name="checkmark-circle" size={20} color={Colors.white} />
              <Text style={styles.saveBtnText}>Create Booking</Text>
            </>
          )}
        </TouchableOpacity>

        <View style={{ height: 60 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark },
  scroll: { padding: Spacing.base, gap: Spacing.base },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.base,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.sm,
  },
  cardTitle: {
    color: Colors.textPrimary,
    fontSize: FontSize.base,
    fontWeight: '700',
    marginBottom: Spacing.xs,
  },
  formGroup: { gap: Spacing.xs },
  label: { color: Colors.textSecondary, fontSize: FontSize.xs, fontWeight: '600' },
  input: {
    backgroundColor: Colors.dark,
    borderRadius: Radii.md,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm + 2,
    color: Colors.textPrimary,
    fontSize: FontSize.sm,
  },
  textArea: { height: 80, textAlignVertical: 'top', paddingTop: Spacing.md },
  row: { flexDirection: 'row', gap: Spacing.sm },
  halfField: { flex: 1 },
  divider: { height: 1, backgroundColor: Colors.border },
  selectRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: Spacing.sm,
    backgroundColor: Colors.dark,
    borderRadius: Radii.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  selectLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flex: 1 },
  selectLabel: { color: Colors.textMuted, fontSize: 10, fontWeight: '600' },
  selectValue: { color: Colors.textPrimary, fontSize: FontSize.sm, fontWeight: '600' },
  selectPlaceholder: { color: Colors.textMuted, fontSize: FontSize.sm },
  paymentMethods: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.xs },
  methodBtn: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radii.full,
    backgroundColor: Colors.dark,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  methodBtnActive: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  methodText: { color: Colors.textMuted, fontSize: 10, fontWeight: '700' },
  methodTextActive: { color: Colors.white },
  totalBox: {
    backgroundColor: Colors.dark,
    borderRadius: Radii.md,
    padding: Spacing.md,
    gap: Spacing.xs,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between' },
  totalLabel: { color: Colors.textSecondary, fontSize: FontSize.sm },
  totalValue: { color: Colors.textPrimary, fontSize: FontSize.sm, fontWeight: '600' },
  totalFinalRow: {
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingTop: Spacing.xs,
    marginTop: Spacing.xs,
  },
  totalFinalLabel: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  totalFinalValue: { color: Colors.accent, fontSize: FontSize.lg, fontWeight: '800' },
  saveBtn: {
    backgroundColor: Colors.accent,
    borderRadius: Radii.xl,
    padding: Spacing.base,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    ...Shadow.md,
  },
  saveBtnText: { color: Colors.white, fontSize: FontSize.base, fontWeight: '700' },
});
