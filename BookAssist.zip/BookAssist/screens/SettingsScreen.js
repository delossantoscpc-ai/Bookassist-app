// screens/SettingsScreen.js
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Switch,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import AppHeader from '../components/AppHeader';
import ModeToggle from '../components/ModeToggle';
import { Colors, Spacing, Radii, FontSize } from '../utils/theme';

const SettingRow = ({ icon, label, sublabel, onPress, rightElement, danger }) => (
  <TouchableOpacity style={styles.settingRow} onPress={onPress} disabled={!onPress}>
    <View style={[styles.settingIcon, { backgroundColor: danger ? Colors.error + '22' : Colors.surface }]}>
      <Ionicons name={icon} size={18} color={danger ? Colors.error : Colors.textSecondary} />
    </View>
    <View style={styles.settingInfo}>
      <Text style={[styles.settingLabel, danger && { color: Colors.error }]}>{label}</Text>
      {sublabel && <Text style={styles.settingSub}>{sublabel}</Text>}
    </View>
    {rightElement || (onPress && <Ionicons name="chevron-forward" size={16} color={Colors.textMuted} />)}
  </TouchableOpacity>
);

export default function SettingsScreen({ navigation }) {
  const { user, company, isDemoMode, signOut } = useApp();

  const handleSignOut = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign Out', style: 'destructive', onPress: signOut },
    ]);
  };

  return (
    <View style={styles.container}>
      <AppHeader />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Profile */}
        <View style={styles.profileCard}>
          <View style={[styles.profileAvatar, { backgroundColor: company?.logoColor || Colors.accent }]}>
            <Text style={styles.profileEmoji}>{company?.logoEmoji || '🚗'}</Text>
          </View>
          <View style={styles.profileInfo}>
            <Text style={styles.profileName}>{user?.name}</Text>
            <Text style={styles.profileEmail}>{user?.email}</Text>
            <Text style={styles.profileRole}>{user?.role?.toUpperCase()}</Text>
          </View>
        </View>

        {/* Company Info */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Company</Text>
          <View style={styles.card}>
            <View style={styles.companyHeader}>
              <View style={[styles.companyLogo, { backgroundColor: company?.logoColor }]}>
                <Text style={{ fontSize: 20 }}>{company?.logoEmoji}</Text>
              </View>
              <View>
                <Text style={styles.companyName}>{company?.name}</Text>
                <Text style={styles.companyTagline}>{company?.tagline}</Text>
              </View>
            </View>
            <View style={styles.companyDetails}>
              <View style={styles.companyRow}>
                <Ionicons name="location" size={13} color={Colors.textMuted} />
                <Text style={styles.companyDetailText}>{company?.address}</Text>
              </View>
              <View style={styles.companyRow}>
                <Ionicons name="call" size={13} color={Colors.textMuted} />
                <Text style={styles.companyDetailText}>{company?.phone}</Text>
              </View>
              <View style={styles.companyRow}>
                <Ionicons name="mail" size={13} color={Colors.textMuted} />
                <Text style={styles.companyDetailText}>{company?.email}</Text>
              </View>
            </View>
          </View>
        </View>

        {/* App Mode */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>App Mode</Text>
          <View style={styles.card}>
            <View style={styles.modeRow}>
              <View style={styles.modeLeft}>
                <View style={[styles.modeIcon, { backgroundColor: isDemoMode ? Colors.demoBg + '22' : Colors.success + '22' }]}>
                  <Ionicons name={isDemoMode ? 'flask' : 'cloud'} size={20} color={isDemoMode ? Colors.demoBg : Colors.success} />
                </View>
                <View>
                  <Text style={styles.modeName}>{isDemoMode ? 'Demo Mode' : 'Live Mode'}</Text>
                  <Text style={styles.modeSub}>
                    {isDemoMode
                      ? 'Using local mock data. No external APIs.'
                      : 'Connected to Firebase. Real data.'}
                  </Text>
                </View>
              </View>
              <ModeToggle />
            </View>

            {isDemoMode && (
              <View style={styles.demoInfo}>
                <Ionicons name="information-circle" size={14} color={Colors.demoBg} />
                <Text style={styles.demoInfoText}>
                  Demo Mode uses local mock data. Bookings, vehicles, drivers, and customers are simulated. SMS are shown as previews only.
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Firebase Setup (Live Mode only) */}
        {!isDemoMode && (
          <View style={styles.section}>
            <Text style={styles.sectionLabel}>Firebase Configuration</Text>
            <View style={styles.card}>
              <SettingRow
                icon="settings"
                label="Firebase Config"
                sublabel="Edit firebase/config.js with your project"
              />
              <SettingRow
                icon="cloud-upload"
                label="Cloud Functions"
                sublabel="Deploy functions/ for SMS support"
              />
            </View>
          </View>
        )}

        {/* About */}
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>About</Text>
          <View style={styles.card}>
            <SettingRow icon="information-circle" label="BookAssist" sublabel="Car Rental Operations Platform v1.0" />
            <SettingRow icon="code" label="Built with" sublabel="React Native + Expo + Firebase" />
            <SettingRow icon="shield-checkmark" label="Multi-Tenant" sublabel="Each company has isolated data" />
          </View>
        </View>

        {/* Sign Out */}
        <View style={styles.section}>
          <View style={styles.card}>
            <SettingRow
              icon="log-out"
              label="Sign Out"
              sublabel={`Signed in as ${user?.email}`}
              onPress={handleSignOut}
              danger
            />
          </View>
        </View>

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark },
  scroll: { padding: Spacing.base, gap: Spacing.base },

  profileCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.xl,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.base,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  profileAvatar: {
    width: 64,
    height: 64,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileEmoji: { fontSize: 32 },
  profileInfo: { flex: 1 },
  profileName: { color: Colors.textPrimary, fontSize: FontSize.lg, fontWeight: '800' },
  profileEmail: { color: Colors.textSecondary, fontSize: FontSize.sm },
  profileRole: {
    color: Colors.accent,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1,
    marginTop: 4,
    backgroundColor: Colors.accent + '15',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
    alignSelf: 'flex-start',
  },

  section: { gap: Spacing.sm },
  sectionLabel: {
    color: Colors.textMuted,
    fontSize: FontSize.xs,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 1,
    paddingLeft: Spacing.xs,
  },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
  },

  companyHeader: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, padding: Spacing.base },
  companyLogo: { width: 48, height: 48, borderRadius: 14, justifyContent: 'center', alignItems: 'center' },
  companyName: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  companyTagline: { color: Colors.textMuted, fontSize: FontSize.xs },
  companyDetails: {
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    padding: Spacing.base,
    gap: Spacing.sm,
  },
  companyRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  companyDetailText: { color: Colors.textSecondary, fontSize: FontSize.xs, flex: 1 },

  modeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: Spacing.base,
  },
  modeLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md, flex: 1 },
  modeIcon: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  modeName: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  modeSub: { color: Colors.textSecondary, fontSize: FontSize.xs, maxWidth: 160 },
  demoInfo: {
    flexDirection: 'row',
    gap: Spacing.sm,
    backgroundColor: Colors.demoBg + '11',
    margin: Spacing.sm,
    marginTop: 0,
    borderRadius: Radii.md,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.demoBg + '33',
  },
  demoInfoText: { color: Colors.demoBg, fontSize: FontSize.xs, flex: 1, lineHeight: 18 },

  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.base,
    gap: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  settingIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingInfo: { flex: 1 },
  settingLabel: { color: Colors.textPrimary, fontSize: FontSize.sm, fontWeight: '600' },
  settingSub: { color: Colors.textMuted, fontSize: FontSize.xs, marginTop: 1 },
});
