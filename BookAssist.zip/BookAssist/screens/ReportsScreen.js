// screens/ReportsScreen.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import { fetchBookings, fetchVehicles, fetchDrivers } from '../services/dataService';
import AppHeader from '../components/AppHeader';
import LoadingScreen from '../components/LoadingScreen';
import { Colors, Spacing, Radii, FontSize, formatCurrency } from '../utils/theme';
import { BOOKING_STATUS_COLORS, BOOKING_STATUS_LABELS } from '../mock/bookings';

const MetricCard = ({ icon, label, value, color, sub }) => (
  <View style={[styles.metricCard, { borderLeftColor: color, borderLeftWidth: 3 }]}>
    <View style={[styles.metricIcon, { backgroundColor: color + '22' }]}>
      <Ionicons name={icon} size={18} color={color} />
    </View>
    <View style={styles.metricInfo}>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricLabel}>{label}</Text>
      {sub && <Text style={styles.metricSub}>{sub}</Text>}
    </View>
  </View>
);

const BarRow = ({ label, value, max, color, count }) => {
  const pct = max > 0 ? (value / max) * 100 : 0;
  return (
    <View style={styles.barRow}>
      <Text style={styles.barLabel}>{label}</Text>
      <View style={styles.barTrack}>
        <View style={[styles.barFill, { width: `${pct}%`, backgroundColor: color }]} />
      </View>
      <View style={styles.barRight}>
        <Text style={styles.barValue}>{formatCurrency(value)}</Text>
        {count !== undefined && <Text style={styles.barCount}>{count}x</Text>}
      </View>
    </View>
  );
};

export default function ReportsScreen() {
  const { isDemoMode, user } = useApp();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [data, setData] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');

  const load = useCallback(async () => {
    try {
      const [bookings, vehicles, drivers] = await Promise.all([
        fetchBookings(isDemoMode, user.companyId),
        fetchVehicles(isDemoMode, user.companyId),
        fetchDrivers(isDemoMode, user.companyId),
      ]);

      // Revenue breakdown
      const paid = bookings.filter(b => b.paymentStatus === 'paid');
      const totalRevenue = paid.reduce((s, b) => s + (b.finalAmount || 0), 0);
      const totalPending = bookings
        .filter(b => b.paymentStatus !== 'paid' && b.status !== 'cancelled')
        .reduce((s, b) => s + (b.finalAmount || 0), 0);

      // Status breakdown
      const statusCounts = {};
      bookings.forEach(b => {
        statusCounts[b.status] = (statusCounts[b.status] || 0) + 1;
      });

      // Revenue by vehicle
      const vehicleRevenue = {};
      bookings.filter(b => b.paymentStatus === 'paid' && b.vehicleName).forEach(b => {
        const key = b.vehicleName;
        if (!vehicleRevenue[key]) vehicleRevenue[key] = { revenue: 0, count: 0 };
        vehicleRevenue[key].revenue += b.finalAmount || 0;
        vehicleRevenue[key].count += 1;
      });
      const vehicleRevList = Object.entries(vehicleRevenue)
        .map(([name, d]) => ({ name, ...d }))
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 5);

      // Revenue by driver
      const driverRevenue = {};
      bookings.filter(b => b.paymentStatus === 'paid' && b.driverName).forEach(b => {
        const key = b.driverName;
        if (!driverRevenue[key]) driverRevenue[key] = { revenue: 0, count: 0 };
        driverRevenue[key].revenue += b.finalAmount || 0;
        driverRevenue[key].count += 1;
      });
      const driverRevList = Object.entries(driverRevenue)
        .map(([name, d]) => ({ name, ...d }))
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 5);

      // Payment method breakdown
      const paymentMethods = {};
      bookings.filter(b => b.paymentMethod).forEach(b => {
        paymentMethods[b.paymentMethod] = (paymentMethods[b.paymentMethod] || 0) + 1;
      });

      // Avg booking value
      const avgBookingValue = paid.length > 0 ? totalRevenue / paid.length : 0;

      // Fleet utilization
      const onTrip = vehicles.filter(v => v.status === 'on_trip').length;
      const utilization = vehicles.length > 0 ? (onTrip / vehicles.length) * 100 : 0;

      // Top performing driver (most trips)
      const topDriver = drivers.sort((a, b) => b.totalTrips - a.totalTrips)[0];

      setData({
        totalRevenue,
        totalPending,
        totalBookings: bookings.length,
        completedBookings: bookings.filter(b => b.status === 'completed').length,
        cancelledBookings: bookings.filter(b => b.status === 'cancelled').length,
        statusCounts,
        vehicleRevList,
        driverRevList,
        paymentMethods,
        avgBookingValue,
        utilization,
        topDriver,
        totalVehicles: vehicles.length,
        totalDrivers: drivers.length,
      });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [isDemoMode, user?.companyId]);

  useEffect(() => { load(); }, [load]);

  if (loading) return <LoadingScreen message="Generating reports..." />;

  const maxVehicleRev = data?.vehicleRevList?.[0]?.revenue || 1;
  const maxDriverRev = data?.driverRevList?.[0]?.revenue || 1;

  return (
    <View style={styles.container}>
      <AppHeader />

      {/* Tabs */}
      <View style={styles.tabs}>
        {['overview', 'vehicles', 'drivers'].map(tab => (
          <TouchableOpacity
            key={tab}
            style={[styles.tab, activeTab === tab && styles.tabActive]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={Colors.accent} />
        }
      >
        {activeTab === 'overview' && (
          <>
            <Text style={styles.sectionTitle}>Financial Summary</Text>
            <View style={styles.metrics}>
              <MetricCard icon="cash" label="Total Revenue Collected" value={formatCurrency(data?.totalRevenue)} color={Colors.success} sub={`${data?.completedBookings} paid bookings`} />
              <MetricCard icon="time" label="Outstanding / Pending" value={formatCurrency(data?.totalPending)} color={Colors.warning} sub="Not yet collected" />
              <MetricCard icon="trending-up" label="Avg Booking Value" value={formatCurrency(data?.avgBookingValue)} color={Colors.accent} />
              <MetricCard icon="analytics" label="Fleet Utilization" value={`${data?.utilization?.toFixed(0)}%`} color={Colors.purple} sub={`${data?.totalVehicles} total vehicles`} />
            </View>

            <Text style={styles.sectionTitle}>Booking Status Breakdown</Text>
            <View style={styles.card}>
              {Object.entries(data?.statusCounts || {}).map(([status, count]) => (
                <View key={status} style={styles.statusRow}>
                  <View style={styles.statusLeft}>
                    <View style={[styles.statusDot, { backgroundColor: BOOKING_STATUS_COLORS[status] }]} />
                    <Text style={styles.statusLabel}>{BOOKING_STATUS_LABELS[status] || status}</Text>
                  </View>
                  <View style={styles.statusRight}>
                    <View style={[styles.statusBar, { backgroundColor: BOOKING_STATUS_COLORS[status] + '22' }]}>
                      <View
                        style={[
                          styles.statusBarFill,
                          {
                            backgroundColor: BOOKING_STATUS_COLORS[status],
                            width: `${(count / data.totalBookings) * 100}%`,
                          },
                        ]}
                      />
                    </View>
                    <Text style={styles.statusCount}>{count}</Text>
                  </View>
                </View>
              ))}
            </View>

            <Text style={styles.sectionTitle}>Payment Methods</Text>
            <View style={styles.card}>
              {Object.entries(data?.paymentMethods || {}).map(([method, count]) => (
                <View key={method} style={styles.methodRow}>
                  <Ionicons name="card" size={14} color={Colors.accent} />
                  <Text style={styles.methodLabel}>{method.replace('_', ' ').toUpperCase()}</Text>
                  <Text style={styles.methodCount}>{count} booking{count !== 1 ? 's' : ''}</Text>
                </View>
              ))}
            </View>

            {data?.topDriver && (
              <>
                <Text style={styles.sectionTitle}>Top Performing Driver</Text>
                <View style={styles.topDriverCard}>
                  <View style={styles.topDriverAvatar}>
                    <Text style={styles.topDriverInitials}>
                      {data.topDriver.firstName?.[0]}{data.topDriver.lastName?.[0]}
                    </Text>
                  </View>
                  <View style={styles.topDriverInfo}>
                    <Text style={styles.topDriverName}>{data.topDriver.firstName} {data.topDriver.lastName}</Text>
                    <Text style={styles.topDriverSub}>{data.topDriver.totalTrips} total trips · ⭐ {data.topDriver.rating}</Text>
                  </View>
                  <View style={styles.topDriverBadge}>
                    <Text style={styles.topDriverBadgeText}>🏆 Top</Text>
                  </View>
                </View>
              </>
            )}
          </>
        )}

        {activeTab === 'vehicles' && (
          <>
            <Text style={styles.sectionTitle}>Revenue by Vehicle</Text>
            <View style={styles.card}>
              {data?.vehicleRevList?.length > 0 ? (
                data.vehicleRevList.map(v => (
                  <BarRow
                    key={v.name}
                    label={v.name}
                    value={v.revenue}
                    max={maxVehicleRev}
                    color={Colors.accent}
                    count={v.count}
                  />
                ))
              ) : (
                <Text style={styles.empty}>No revenue data yet</Text>
              )}
            </View>
          </>
        )}

        {activeTab === 'drivers' && (
          <>
            <Text style={styles.sectionTitle}>Revenue by Driver</Text>
            <View style={styles.card}>
              {data?.driverRevList?.length > 0 ? (
                data.driverRevList.map(d => (
                  <BarRow
                    key={d.name}
                    label={d.name}
                    value={d.revenue}
                    max={maxDriverRev}
                    color={Colors.success}
                    count={d.count}
                  />
                ))
              ) : (
                <Text style={styles.empty}>No revenue data yet</Text>
              )}
            </View>
          </>
        )}

        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark },
  tabs: {
    flexDirection: 'row',
    margin: Spacing.base,
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: 4,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  tab: { flex: 1, paddingVertical: Spacing.sm, alignItems: 'center', borderRadius: Radii.md },
  tabActive: { backgroundColor: Colors.accent },
  tabText: { color: Colors.textSecondary, fontSize: FontSize.sm, fontWeight: '600' },
  tabTextActive: { color: Colors.white },
  scroll: { padding: Spacing.base, gap: Spacing.base },
  sectionTitle: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  metrics: { gap: Spacing.sm },
  metricCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.base,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  metricIcon: { width: 40, height: 40, borderRadius: 12, justifyContent: 'center', alignItems: 'center' },
  metricInfo: { flex: 1 },
  metricValue: { color: Colors.textPrimary, fontSize: FontSize.lg, fontWeight: '800' },
  metricLabel: { color: Colors.textSecondary, fontSize: FontSize.xs },
  metricSub: { color: Colors.textMuted, fontSize: 10, marginTop: 2 },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.base,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.md,
  },
  statusRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  statusLeft: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flex: 1 },
  statusDot: { width: 8, height: 8, borderRadius: 4 },
  statusLabel: { color: Colors.textSecondary, fontSize: FontSize.sm },
  statusRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm, flex: 1, justifyContent: 'flex-end' },
  statusBar: { height: 6, flex: 1, borderRadius: 3, overflow: 'hidden' },
  statusBarFill: { height: '100%', borderRadius: 3 },
  statusCount: { color: Colors.textPrimary, fontSize: FontSize.sm, fontWeight: '700', minWidth: 20, textAlign: 'right' },
  methodRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  methodLabel: { color: Colors.textSecondary, fontSize: FontSize.sm, flex: 1 },
  methodCount: { color: Colors.textPrimary, fontSize: FontSize.sm, fontWeight: '700' },
  topDriverCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.base,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.warning + '40',
  },
  topDriverAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: Colors.warning + '22',
    justifyContent: 'center',
    alignItems: 'center',
  },
  topDriverInitials: { color: Colors.warning, fontSize: FontSize.base, fontWeight: '700' },
  topDriverInfo: { flex: 1 },
  topDriverName: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  topDriverSub: { color: Colors.textSecondary, fontSize: FontSize.xs },
  topDriverBadge: { backgroundColor: Colors.warning + '22', paddingHorizontal: 12, paddingVertical: 6, borderRadius: Radii.full },
  topDriverBadgeText: { color: Colors.warning, fontSize: FontSize.sm, fontWeight: '700' },
  barRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.sm },
  barLabel: { color: Colors.textSecondary, fontSize: FontSize.xs, width: 110 },
  barTrack: { flex: 1, height: 8, backgroundColor: Colors.dark, borderRadius: 4, overflow: 'hidden' },
  barFill: { height: '100%', borderRadius: 4 },
  barRight: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, minWidth: 90, justifyContent: 'flex-end' },
  barValue: { color: Colors.textPrimary, fontSize: FontSize.xs, fontWeight: '700' },
  barCount: { color: Colors.textMuted, fontSize: FontSize.xs },
  empty: { color: Colors.textMuted, fontSize: FontSize.sm, textAlign: 'center', padding: Spacing.base },
});
