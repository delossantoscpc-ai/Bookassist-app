// screens/LoginScreen.js
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import ModeToggle from '../components/ModeToggle';
import { Colors, Spacing, Radii, FontSize, Shadow } from '../utils/theme';
import { MOCK_USERS } from '../mock/users';

const DEMO_ACCOUNTS = MOCK_USERS.map(u => ({
  email: u.email,
  password: u.password,
  company: u.companyName,
}));

export default function LoginScreen() {
  const { signIn, isDemoMode } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Missing Fields', 'Please enter email and password.');
      return;
    }
    setLoading(true);
    try {
      await signIn(email.trim(), password.trim());
    } catch (err) {
      Alert.alert('Login Failed', err.message);
    } finally {
      setLoading(false);
    }
  };

  const quickLogin = (account) => {
    setEmail(account.email);
    setPassword(account.password);
  };

  return (
    <LinearGradient colors={[Colors.darker, Colors.dark, '#1a2744']} style={styles.gradient}>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          {/* Mode Toggle */}
          <View style={styles.topBar}>
            <ModeToggle />
          </View>

          {/* Logo */}
          <View style={styles.logoSection}>
            <View style={styles.logoCircle}>
              <Text style={styles.logoIcon}>🚗</Text>
            </View>
            <Text style={styles.appName}>BookAssist</Text>
            <Text style={styles.tagline}>Car Rental Operations Platform</Text>
            {isDemoMode && (
              <View style={styles.modePill}>
                <Ionicons name="flask" size={12} color={Colors.demoText} />
                <Text style={styles.modePillText}>Demo Mode Active</Text>
              </View>
            )}
          </View>

          {/* Login Form */}
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Sign In</Text>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Email</Text>
              <View style={styles.inputRow}>
                <Ionicons name="mail" size={18} color={Colors.textMuted} style={styles.inputIcon} />
                <TextInput
                  style={styles.input}
                  value={email}
                  onChangeText={setEmail}
                  placeholder="your@email.com"
                  placeholderTextColor={Colors.textMuted}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Password</Text>
              <View style={styles.inputRow}>
                <Ionicons name="lock-closed" size={18} color={Colors.textMuted} style={styles.inputIcon} />
                <TextInput
                  style={[styles.input, styles.passwordInput]}
                  value={password}
                  onChangeText={setPassword}
                  placeholder="Password"
                  placeholderTextColor={Colors.textMuted}
                  secureTextEntry={!showPassword}
                  autoCapitalize="none"
                />
                <TouchableOpacity onPress={() => setShowPassword(!showPassword)} style={styles.eyeBtn}>
                  <Ionicons
                    name={showPassword ? 'eye-off' : 'eye'}
                    size={18}
                    color={Colors.textMuted}
                  />
                </TouchableOpacity>
              </View>
            </View>

            <TouchableOpacity
              style={[styles.loginBtn, loading && styles.loginBtnDisabled]}
              onPress={handleLogin}
              disabled={loading}
            >
              {loading ? (
                <ActivityIndicator color={Colors.white} />
              ) : (
                <>
                  <Text style={styles.loginBtnText}>Sign In</Text>
                  <Ionicons name="arrow-forward" size={18} color={Colors.white} />
                </>
              )}
            </TouchableOpacity>
          </View>

          {/* Demo Accounts */}
          {isDemoMode && (
            <View style={styles.demoSection}>
              <View style={styles.demoHeader}>
                <Ionicons name="flask" size={14} color={Colors.demoBg} />
                <Text style={styles.demoHeaderText}>Demo Accounts — tap to fill</Text>
              </View>
              {DEMO_ACCOUNTS.map((account, i) => (
                <TouchableOpacity
                  key={i}
                  style={styles.demoAccountRow}
                  onPress={() => quickLogin(account)}
                >
                  <View style={styles.demoAccountIcon}>
                    <Text style={{ fontSize: 16 }}>
                      {['🚗', '🏎️', '🌴'][i]}
                    </Text>
                  </View>
                  <View style={styles.demoAccountInfo}>
                    <Text style={styles.demoAccountCompany}>{account.company}</Text>
                    <Text style={styles.demoAccountEmail}>{account.email}</Text>
                    <Text style={styles.demoAccountPass}>Password: {account.password}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={16} color={Colors.textMuted} />
                </TouchableOpacity>
              ))}
            </View>
          )}

          {!isDemoMode && (
            <View style={styles.liveNotice}>
              <Ionicons name="cloud" size={16} color={Colors.accent} />
              <Text style={styles.liveNoticeText}>
                Live Mode: Use your Firebase credentials. Configure firebase/config.js with your project details.
              </Text>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  gradient: { flex: 1 },
  flex: { flex: 1 },
  scroll: { padding: Spacing.base, paddingBottom: 60 },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: Spacing.base,
    marginTop: Spacing.sm,
  },
  logoSection: {
    alignItems: 'center',
    paddingVertical: Spacing.xxl,
    gap: Spacing.sm,
  },
  logoCircle: {
    width: 80,
    height: 80,
    borderRadius: 24,
    backgroundColor: Colors.accent,
    justifyContent: 'center',
    alignItems: 'center',
    ...Shadow.lg,
  },
  logoIcon: { fontSize: 40 },
  appName: {
    color: Colors.textPrimary,
    fontSize: FontSize.xxl,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  tagline: {
    color: Colors.textMuted,
    fontSize: FontSize.sm,
    textAlign: 'center',
  },
  modePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.demoBg,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: Radii.full,
    marginTop: Spacing.xs,
  },
  modePillText: {
    color: Colors.demoText,
    fontSize: FontSize.xs,
    fontWeight: '700',
  },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.base,
    ...Shadow.md,
  },
  cardTitle: {
    color: Colors.textPrimary,
    fontSize: FontSize.lg,
    fontWeight: '800',
    marginBottom: Spacing.xs,
  },
  inputGroup: { gap: Spacing.xs },
  inputLabel: {
    color: Colors.textSecondary,
    fontSize: FontSize.sm,
    fontWeight: '600',
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.dark,
    borderRadius: Radii.md,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: Spacing.md,
    height: 48,
    gap: Spacing.sm,
  },
  inputIcon: {},
  input: {
    flex: 1,
    color: Colors.textPrimary,
    fontSize: FontSize.base,
  },
  passwordInput: { flex: 1 },
  eyeBtn: { padding: Spacing.xs },
  loginBtn: {
    backgroundColor: Colors.accent,
    borderRadius: Radii.lg,
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.sm,
    marginTop: Spacing.sm,
    ...Shadow.md,
  },
  loginBtnDisabled: { opacity: 0.6 },
  loginBtnText: {
    color: Colors.white,
    fontSize: FontSize.base,
    fontWeight: '700',
  },
  demoSection: {
    marginTop: Spacing.xl,
    gap: Spacing.sm,
  },
  demoHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.xs,
  },
  demoHeaderText: {
    color: Colors.demoBg,
    fontSize: FontSize.sm,
    fontWeight: '700',
  },
  demoAccountRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.md,
  },
  demoAccountIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: Colors.dark,
    justifyContent: 'center',
    alignItems: 'center',
  },
  demoAccountInfo: { flex: 1 },
  demoAccountCompany: {
    color: Colors.textPrimary,
    fontSize: FontSize.sm,
    fontWeight: '700',
  },
  demoAccountEmail: {
    color: Colors.textSecondary,
    fontSize: FontSize.xs,
  },
  demoAccountPass: {
    color: Colors.textMuted,
    fontSize: FontSize.xs,
  },
  liveNotice: {
    flexDirection: 'row',
    gap: Spacing.sm,
    backgroundColor: Colors.accent + '11',
    borderRadius: Radii.md,
    padding: Spacing.base,
    marginTop: Spacing.xl,
    borderWidth: 1,
    borderColor: Colors.accent + '33',
  },
  liveNoticeText: {
    color: Colors.accent,
    fontSize: FontSize.xs,
    flex: 1,
    lineHeight: 18,
  },
});
