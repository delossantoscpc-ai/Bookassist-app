// screens/CustomersScreen.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import { fetchCustomers } from '../services/dataService';
import AppHeader from '../components/AppHeader';
import StatusBadge from '../components/StatusBadge';
import EmptyState from '../components/EmptyState';
import LoadingScreen from '../components/LoadingScreen';
import { Colors, Spacing, Radii, FontSize, formatCurrency, formatDate } from '../utils/theme';
import { CUSTOMER_STATUS_COLORS, CUSTOMER_STATUS_LABELS } from '../mock/customers';

export default function CustomersScreen({ navigation }) {
  const { isDemoMode, user } = useApp();
  const [customers, setCustomers] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');

  const load = useCallback(async () => {
    const data = await fetchCustomers(isDemoMode, user.companyId);
    setCustomers(data);
    setLoading(false);
    setRefreshing(false);
  }, [isDemoMode, user?.companyId]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!search.trim()) { setFiltered(customers); return; }
    const q = search.toLowerCase();
    setFiltered(customers.filter(c =>
      c.firstName?.toLowerCase().includes(q) ||
      c.lastName?.toLowerCase().includes(q) ||
      c.phone?.includes(q) ||
      c.email?.toLowerCase().includes(q) ||
      c.nationality?.toLowerCase().includes(q)
    ));
  }, [customers, search]);

  if (loading) return <LoadingScreen message="Loading customers..." />;

  const renderCustomer = ({ item }) => (
    <View style={styles.card}>
      <View style={styles.cardTop}>
        <View style={[styles.avatar, { backgroundColor: CUSTOMER_STATUS_COLORS[item.status] + '22' }]}>
          <Text style={styles.avatarText}>{item.firstName?.[0]}{item.lastName?.[0]}</Text>
        </View>
        <View style={styles.info}>
          <View style={styles.nameRow}>
            <Text style={styles.name}>{item.firstName} {item.lastName}</Text>
            {item.status === 'vip' && (
              <View style={styles.vipBadge}>
                <Text style={styles.vipText}>👑 VIP</Text>
              </View>
            )}
          </View>
          <Text style={styles.nationality}>{item.nationality}</Text>
          <Text style={styles.phone}>{item.phone}</Text>
        </View>
        <StatusBadge label={CUSTOMER_STATUS_LABELS[item.status]} color={CUSTOMER_STATUS_COLORS[item.status]} />
      </View>

      <View style={styles.statsRow}>
        <View style={styles.stat}>
          <Text style={styles.statValue}>{item.totalBookings}</Text>
          <Text style={styles.statLabel}>Bookings</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.stat}>
          <Text style={styles.statValue}>{formatCurrency(item.totalSpent)}</Text>
          <Text style={styles.statLabel}>Total Spent</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.stat}>
          <Text style={styles.statValue}>{formatDate(item.lastBooking)}</Text>
          <Text style={styles.statLabel}>Last Booking</Text>
        </View>
      </View>

      <View style={styles.idRow}>
        <Ionicons name="card" size={12} color={Colors.textMuted} />
        <Text style={styles.idText}>{item.idType}: {item.idNumber}</Text>
      </View>

      {item.notes && (
        <View style={styles.notesBox}>
          <Ionicons name="chatbubble" size={11} color={Colors.textMuted} />
          <Text style={styles.notesText}>{item.notes}</Text>
        </View>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <AppHeader
        rightAction={
          <TouchableOpacity style={styles.addBtn}>
            <Ionicons name="add" size={20} color={Colors.white} />
          </TouchableOpacity>
        }
      />

      <View style={styles.searchRow}>
        <Ionicons name="search" size={16} color={Colors.textMuted} />
        <TextInput
          style={styles.searchInput}
          value={search}
          onChangeText={setSearch}
          placeholder="Search customers..."
          placeholderTextColor={Colors.textMuted}
        />
      </View>

      <Text style={styles.countText}>{filtered.length} customer{filtered.length !== 1 ? 's' : ''}</Text>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        renderItem={renderCustomer}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={Colors.accent} />
        }
        ListEmptyComponent={
          <EmptyState icon="people" title="No Customers Found" subtitle="No customers match your search." />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark },
  addBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.accent, justifyContent: 'center', alignItems: 'center' },
  searchRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.surface, margin: Spacing.base, borderRadius: Radii.lg, paddingHorizontal: Spacing.md, height: 44, gap: Spacing.sm, borderWidth: 1, borderColor: Colors.border },
  searchInput: { flex: 1, color: Colors.textPrimary, fontSize: FontSize.sm },
  countText: { color: Colors.textMuted, fontSize: FontSize.xs, paddingHorizontal: Spacing.base, paddingVertical: Spacing.xs },
  list: { padding: Spacing.base, gap: Spacing.sm, paddingBottom: 80 },
  card: { backgroundColor: Colors.surface, borderRadius: Radii.xl, padding: Spacing.base, borderWidth: 1, borderColor: Colors.border, gap: Spacing.sm },
  cardTop: { flexDirection: 'row', alignItems: 'center', gap: Spacing.md },
  avatar: { width: 48, height: 48, borderRadius: 24, justifyContent: 'center', alignItems: 'center' },
  avatarText: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  info: { flex: 1 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  name: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  vipBadge: { backgroundColor: Colors.warning + '22', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  vipText: { fontSize: 10, color: Colors.warning, fontWeight: '700' },
  nationality: { color: Colors.textMuted, fontSize: FontSize.xs },
  phone: { color: Colors.textSecondary, fontSize: FontSize.xs },
  statsRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: Colors.dark, borderRadius: Radii.md, padding: Spacing.md },
  stat: { flex: 1, alignItems: 'center', gap: 2 },
  statValue: { color: Colors.textPrimary, fontSize: FontSize.sm, fontWeight: '700' },
  statLabel: { color: Colors.textMuted, fontSize: 9, textAlign: 'center' },
  statDivider: { width: 1, height: 30, backgroundColor: Colors.border },
  idRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  idText: { color: Colors.textMuted, fontSize: FontSize.xs },
  notesBox: { flexDirection: 'row', gap: Spacing.xs, backgroundColor: Colors.dark, borderRadius: Radii.md, padding: Spacing.sm, borderWidth: 1, borderColor: Colors.border },
  notesText: { color: Colors.textMuted, fontSize: FontSize.xs, flex: 1, lineHeight: 16 },
});
