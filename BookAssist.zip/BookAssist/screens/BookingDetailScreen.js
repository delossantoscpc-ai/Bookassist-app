// screens/BookingDetailScreen.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import { fetchBookingById, confirmBooking, updateBooking } from '../services/dataService';
import { sendConfirmationSms } from '../services/smsService';
import AppHeader from '../components/AppHeader';
import StatusBadge from '../components/StatusBadge';
import SmsPreviewModal from '../components/SmsPreviewModal';
import LoadingScreen from '../components/LoadingScreen';
import {
  Colors,
  Spacing,
  Radii,
  FontSize,
  Shadow,
  formatCurrency,
  formatDate,
} from '../utils/theme';
import {
  BOOKING_STATUS_COLORS,
  BOOKING_STATUS_LABELS,
  PAYMENT_STATUS_COLORS,
} from '../mock/bookings';

const InfoRow = ({ icon, label, value, valueColor }) => (
  <View style={styles.infoRow}>
    <View style={styles.infoIcon}>
      <Ionicons name={icon} size={14} color={Colors.textMuted} />
    </View>
    <View style={styles.infoContent}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={[styles.infoValue, valueColor && { color: valueColor }]}>{value || 'N/A'}</Text>
    </View>
  </View>
);

const Section = ({ title, children }) => (
  <View style={styles.section}>
    <Text style={styles.sectionTitle}>{title}</Text>
    <View style={styles.sectionCard}>{children}</View>
  </View>
);

export default function BookingDetailScreen({ navigation, route }) {
  const { bookingId } = route.params;
  const { isDemoMode, company } = useApp();
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const [confirming, setConfirming] = useState(false);
  const [smsModal, setSmsModal] = useState(false);
  const [smsData, setSmsData] = useState(null);

  const load = useCallback(async () => {
    const data = await fetchBookingById(isDemoMode, bookingId);
    setBooking(data);
    setLoading(false);
  }, [isDemoMode, bookingId]);

  useEffect(() => { load(); }, [load]);

  const handleConfirm = async () => {
    if (!booking.driverId || !booking.vehicleId) {
      Alert.alert(
        'Incomplete Booking',
        'Please assign a driver and vehicle before confirming.'
      );
      return;
    }
    setConfirming(true);
    try {
      const updated = await confirmBooking(isDemoMode, booking.id);
      const smsResult = await sendConfirmationSms(isDemoMode, booking, company);
      setBooking({ ...booking, ...updated });

      if (smsResult.demo) {
        // Show SMS preview modal in demo mode
        setSmsData(smsResult.messages);
        setSmsModal(true);
      } else {
        Alert.alert('✅ Booking Confirmed', 'SMS sent to driver and customer.');
      }
    } catch (e) {
      Alert.alert('Error', e.message);
    } finally {
      setConfirming(false);
    }
  };

  const handleCancel = () => {
    Alert.alert(
      'Cancel Booking',
      'Are you sure you want to cancel this booking?',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, Cancel',
          style: 'destructive',
          onPress: async () => {
            await updateBooking(isDemoMode, booking.id, { status: 'cancelled' });
            setBooking({ ...booking, status: 'cancelled' });
          },
        },
      ]
    );
  };

  const handleMarkComplete = async () => {
    await updateBooking(isDemoMode, booking.id, { status: 'completed' });
    setBooking({ ...booking, status: 'completed' });
  };

  const handleMarkPaid = async () => {
    await updateBooking(isDemoMode, booking.id, { paymentStatus: 'paid' });
    setBooking({ ...booking, paymentStatus: 'paid' });
    Alert.alert('✅ Payment Recorded', 'Booking marked as paid.');
  };

  if (loading) return <LoadingScreen />;
  if (!booking) return (
    <View style={styles.container}>
      <AppHeader title="Booking Detail" showBack onBack={() => navigation.goBack()} />
      <View style={styles.center}>
        <Text style={styles.notFound}>Booking not found</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <AppHeader
        title="Booking Detail"
        showBack
        onBack={() => navigation.goBack()}
      />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header Card */}
        <View style={styles.headerCard}>
          <View style={styles.headerTop}>
            <Text style={styles.bookingId}>{booking.id}</Text>
            <StatusBadge
              label={BOOKING_STATUS_LABELS[booking.status]}
              color={BOOKING_STATUS_COLORS[booking.status]}
              size="lg"
            />
          </View>
          <Text style={styles.customerName}>{booking.customerName}</Text>
          <View style={styles.routeRow}>
            <Ionicons name="location" size={14} color={Colors.accent} />
            <Text style={styles.location}>{booking.pickupLocation}</Text>
          </View>
          <View style={styles.routeRow}>
            <Ionicons name="flag" size={14} color={Colors.success} />
            <Text style={styles.location}>{booking.dropoffLocation}</Text>
          </View>

          <View style={styles.amountRow}>
            <View>
              <Text style={styles.amountLabel}>Total Amount</Text>
              <Text style={styles.amount}>{formatCurrency(booking.finalAmount)}</Text>
            </View>
            <View style={[styles.payBadge, { backgroundColor: PAYMENT_STATUS_COLORS[booking.paymentStatus] + '22' }]}>
              <Text style={[styles.payText, { color: PAYMENT_STATUS_COLORS[booking.paymentStatus] }]}>
                {booking.paymentStatus?.toUpperCase()}
              </Text>
            </View>
          </View>
        </View>

        {/* Trip Details */}
        <Section title="Trip Details">
          <InfoRow icon="calendar" label="Start Date" value={`${formatDate(booking.startDate)} at ${booking.startTime}`} />
          <InfoRow icon="calendar-outline" label="End Date" value={formatDate(booking.endDate)} />
          <InfoRow icon="moon" label="Duration" value={`${booking.totalDays} day${booking.totalDays !== 1 ? 's' : ''}`} />
          <InfoRow icon="pricetag" label="Daily Rate" value={formatCurrency(booking.dailyRate)} />
          {booking.discount > 0 && (
            <InfoRow icon="gift" label="Discount" value={`-${formatCurrency(booking.discount)}`} valueColor={Colors.success} />
          )}
          <InfoRow icon="cash" label="Payment Method" value={booking.paymentMethod?.replace('_', ' ')?.toUpperCase() || 'Not set'} />
        </Section>

        {/* Vehicle & Driver */}
        <Section title="Vehicle & Driver">
          <InfoRow icon="car" label="Vehicle" value={booking.vehicleName || 'Not assigned'} valueColor={!booking.vehicleName ? Colors.warning : null} />
          {booking.vehiclePlate && <InfoRow icon="barcode" label="Plate Number" value={booking.vehiclePlate} />}
          <InfoRow icon="person" label="Driver" value={booking.driverName || 'Not assigned'} valueColor={!booking.driverName ? Colors.warning : null} />
          {booking.driverPhone && <InfoRow icon="call" label="Driver Phone" value={booking.driverPhone} />}
        </Section>

        {/* Customer */}
        <Section title="Customer">
          <InfoRow icon="person-circle" label="Name" value={booking.customerName} />
          <InfoRow icon="call" label="Phone" value={booking.customerPhone} />
        </Section>

        {/* SMS Status */}
        <View style={styles.smsSection}>
          <Text style={styles.smsSectionTitle}>Notifications</Text>
          <View style={styles.smsRow}>
            <View style={styles.smsItem}>
              <Ionicons
                name={booking.smsDriverSent ? 'checkmark-circle' : 'close-circle'}
                size={16}
                color={booking.smsDriverSent ? Colors.success : Colors.error}
              />
              <Text style={styles.smsText}>SMS to Driver</Text>
            </View>
            <View style={styles.smsItem}>
              <Ionicons
                name={booking.smsCustomerSent ? 'checkmark-circle' : 'close-circle'}
                size={16}
                color={booking.smsCustomerSent ? Colors.success : Colors.error}
              />
              <Text style={styles.smsText}>SMS to Customer</Text>
            </View>
          </View>
        </View>

        {/* Notes */}
        {booking.notes && (
          <Section title="Notes">
            <Text style={styles.notesText}>{booking.notes}</Text>
          </Section>
        )}

        {/* Actions */}
        <View style={styles.actions}>
          {booking.status === 'pending' && (
            <TouchableOpacity
              style={[styles.actionBtn, styles.confirmBtn]}
              onPress={handleConfirm}
              disabled={confirming}
            >
              {confirming ? (
                <ActivityIndicator color={Colors.white} />
              ) : (
                <>
                  <Ionicons name="checkmark-circle" size={18} color={Colors.white} />
                  <Text style={styles.actionBtnText}>Confirm Booking & Send SMS</Text>
                </>
              )}
            </TouchableOpacity>
          )}

          {booking.status === 'on_trip' && (
            <TouchableOpacity
              style={[styles.actionBtn, { backgroundColor: Colors.success }]}
              onPress={handleMarkComplete}
            >
              <Ionicons name="flag" size={18} color={Colors.white} />
              <Text style={styles.actionBtnText}>Mark as Completed</Text>
            </TouchableOpacity>
          )}

          {booking.paymentStatus !== 'paid' && booking.status !== 'cancelled' && (
            <TouchableOpacity
              style={[styles.actionBtn, { backgroundColor: Colors.success }]}
              onPress={handleMarkPaid}
            >
              <Ionicons name="cash" size={18} color={Colors.white} />
              <Text style={styles.actionBtnText}>Mark as Paid</Text>
            </TouchableOpacity>
          )}

          {['pending', 'confirmed'].includes(booking.status) && (
            <TouchableOpacity
              style={[styles.actionBtn, styles.cancelBtn]}
              onPress={handleCancel}
            >
              <Ionicons name="close-circle" size={18} color={Colors.error} />
              <Text style={[styles.actionBtnText, { color: Colors.error }]}>Cancel Booking</Text>
            </TouchableOpacity>
          )}
        </View>

        <View style={{ height: 60 }} />
      </ScrollView>

      {/* SMS Preview Modal (Demo Mode) */}
      <SmsPreviewModal
        visible={smsModal}
        smsData={smsData}
        onClose={() => setSmsModal(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  notFound: { color: Colors.textSecondary, fontSize: FontSize.base },
  scroll: { flex: 1 },
  scrollContent: { padding: Spacing.base, gap: Spacing.base },

  headerCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.xl,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.sm,
    ...Shadow.md,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bookingId: { color: Colors.accent, fontSize: FontSize.xs, fontWeight: '700' },
  customerName: { color: Colors.textPrimary, fontSize: FontSize.xl, fontWeight: '800' },
  routeRow: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  location: { color: Colors.textSecondary, fontSize: FontSize.sm, flex: 1 },
  amountRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: Spacing.sm,
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
  },
  amountLabel: { color: Colors.textMuted, fontSize: FontSize.xs },
  amount: { color: Colors.textPrimary, fontSize: FontSize.xl, fontWeight: '800' },
  payBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: Radii.md,
  },
  payText: { fontSize: FontSize.xs, fontWeight: '800' },

  section: { gap: Spacing.sm },
  sectionTitle: {
    color: Colors.textSecondary,
    fontSize: FontSize.xs,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  sectionCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    gap: Spacing.md,
  },
  infoIcon: {
    width: 28,
    height: 28,
    borderRadius: 8,
    backgroundColor: Colors.dark,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoContent: { flex: 1 },
  infoLabel: { color: Colors.textMuted, fontSize: 10, fontWeight: '600', textTransform: 'uppercase' },
  infoValue: { color: Colors.textPrimary, fontSize: FontSize.sm, fontWeight: '600', marginTop: 2 },

  smsSection: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.base,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.sm,
  },
  smsSectionTitle: {
    color: Colors.textSecondary,
    fontSize: FontSize.xs,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  smsRow: { flexDirection: 'row', gap: Spacing.xl },
  smsItem: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs },
  smsText: { color: Colors.textSecondary, fontSize: FontSize.xs },

  notesText: {
    color: Colors.textSecondary,
    fontSize: FontSize.sm,
    lineHeight: 20,
    padding: Spacing.base,
  },

  actions: { gap: Spacing.sm },
  actionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: Radii.lg,
    padding: Spacing.base,
    gap: Spacing.sm,
    ...Shadow.sm,
  },
  confirmBtn: { backgroundColor: Colors.accent },
  cancelBtn: {
    backgroundColor: Colors.error + '15',
    borderWidth: 1,
    borderColor: Colors.error + '40',
  },
  actionBtnText: {
    color: Colors.white,
    fontSize: FontSize.base,
    fontWeight: '700',
  },
});
