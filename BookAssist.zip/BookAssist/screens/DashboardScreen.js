// screens/DashboardScreen.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import { fetchDashboardStats } from '../services/dataService';
import AppHeader from '../components/AppHeader';
import ModeToggle from '../components/ModeToggle';
import StatusBadge from '../components/StatusBadge';
import LoadingScreen from '../components/LoadingScreen';
import {
  Colors,
  Spacing,
  Radii,
  FontSize,
  Shadow,
  formatCurrency,
  formatDate,
} from '../utils/theme';
import {
  BOOKING_STATUS_COLORS,
  BOOKING_STATUS_LABELS,
} from '../mock/bookings';

const StatCard = ({ label, value, icon, color, subtitle }) => (
  <View style={[styles.statCard, { borderTopColor: color }]}>
    <View style={[styles.statIcon, { backgroundColor: color + '22' }]}>
      <Ionicons name={icon} size={20} color={color} />
    </View>
    <Text style={styles.statValue}>{value}</Text>
    <Text style={styles.statLabel}>{label}</Text>
    {subtitle && <Text style={styles.statSubtitle}>{subtitle}</Text>}
  </View>
);

export default function DashboardScreen({ navigation }) {
  const { isDemoMode, company, user } = useApp();
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadStats = useCallback(async () => {
    try {
      const data = await fetchDashboardStats(isDemoMode, user.companyId);
      setStats(data);
    } catch (e) {
      console.error('Dashboard load error', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [isDemoMode, user?.companyId]);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  const onRefresh = () => {
    setRefreshing(true);
    loadStats();
  };

  if (loading) return <LoadingScreen message="Loading dashboard..." />;

  const today = new Date().toLocaleDateString('en-PH', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <View style={styles.container}>
      <AppHeader
        rightAction={<ModeToggle />}
      />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.accent}
          />
        }
        showsVerticalScrollIndicator={false}
      >
        {/* Welcome */}
        <View style={styles.welcomeSection}>
          <Text style={styles.welcomeText}>Good {getGreeting()}, {user?.name?.split(' ')[0]} 👋</Text>
          <Text style={styles.dateText}>{today}</Text>
        </View>

        {/* Revenue Cards */}
        <View style={styles.revenueRow}>
          <View style={[styles.revenueCard, { backgroundColor: Colors.accent }]}>
            <Text style={styles.revLabel}>Total Revenue</Text>
            <Text style={styles.revAmount}>{formatCurrency(stats?.totalRevenue)}</Text>
            <Text style={styles.revSub}>All time</Text>
          </View>
          <View style={[styles.revenueCard, { backgroundColor: Colors.success }]}>
            <Text style={styles.revLabel}>This Month</Text>
            <Text style={styles.revAmount}>{formatCurrency(stats?.monthRevenue)}</Text>
            <Text style={styles.revSub}>Collected</Text>
          </View>
        </View>

        {/* Stats Grid */}
        <Text style={styles.sectionTitle}>Operations Overview</Text>
        <View style={styles.statsGrid}>
          <StatCard
            label="Active Bookings"
            value={stats?.activeBookings}
            icon="calendar"
            color={Colors.accent}
          />
          <StatCard
            label="Pending"
            value={stats?.pendingBookings}
            icon="time"
            color={Colors.warning}
            subtitle="Need action"
          />
          <StatCard
            label="Vehicles Free"
            value={`${stats?.availableVehicles}/${stats?.totalVehicles}`}
            icon="car"
            color={Colors.success}
          />
          <StatCard
            label="Drivers Free"
            value={`${stats?.availableDrivers}/${stats?.totalDrivers}`}
            icon="person"
            color={Colors.purple}
          />
          <StatCard
            label="Today's Trips"
            value={stats?.todayBookings}
            icon="today"
            color={Colors.pink}
          />
          <StatCard
            label="Customers"
            value={stats?.totalCustomers}
            icon="people"
            color={Colors.accent}
          />
        </View>

        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.quickActions}>
          <TouchableOpacity
            style={styles.qaBtn}
            onPress={() => navigation.navigate('NewBooking')}
          >
            <Ionicons name="add-circle" size={24} color={Colors.accent} />
            <Text style={styles.qaBtnText}>New Booking</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.qaBtn}
            onPress={() => navigation.navigate('Bookings')}
          >
            <Ionicons name="list" size={24} color={Colors.success} />
            <Text style={styles.qaBtnText}>All Bookings</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.qaBtn}
            onPress={() => navigation.navigate('Reports')}
          >
            <Ionicons name="bar-chart" size={24} color={Colors.warning} />
            <Text style={styles.qaBtnText}>Reports</Text>
          </TouchableOpacity>
        </View>

        {/* Recent Bookings */}
        <View style={styles.recentHeader}>
          <Text style={styles.sectionTitle}>Recent Bookings</Text>
          <TouchableOpacity onPress={() => navigation.navigate('Bookings')}>
            <Text style={styles.viewAllText}>View all</Text>
          </TouchableOpacity>
        </View>

        {stats?.recentBookings?.map(booking => (
          <TouchableOpacity
            key={booking.id}
            style={styles.bookingRow}
            onPress={() =>
              navigation.navigate('BookingDetail', { bookingId: booking.id })
            }
          >
            <View style={styles.bookingLeft}>
              <Text style={styles.bookingId}>{booking.id}</Text>
              <Text style={styles.bookingCustomer}>{booking.customerName}</Text>
              <Text style={styles.bookingRoute} numberOfLines={1}>
                {booking.pickupLocation} → {booking.dropoffLocation}
              </Text>
              <Text style={styles.bookingDate}>{formatDate(booking.startDate)} · {booking.startTime}</Text>
            </View>
            <View style={styles.bookingRight}>
              <StatusBadge
                label={BOOKING_STATUS_LABELS[booking.status]}
                color={BOOKING_STATUS_COLORS[booking.status]}
              />
              <Text style={styles.bookingAmount}>{formatCurrency(booking.finalAmount)}</Text>
              <Ionicons name="chevron-forward" size={16} color={Colors.textMuted} />
            </View>
          </TouchableOpacity>
        ))}

        {/* Spacer */}
        <View style={{ height: 80 }} />
      </ScrollView>
    </View>
  );
}

const getGreeting = () => {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark },
  scroll: { flex: 1 },
  scrollContent: { padding: Spacing.base, gap: Spacing.base },

  welcomeSection: { paddingVertical: Spacing.sm },
  welcomeText: {
    color: Colors.textPrimary,
    fontSize: FontSize.lg,
    fontWeight: '800',
  },
  dateText: {
    color: Colors.textMuted,
    fontSize: FontSize.xs,
    marginTop: 2,
  },

  revenueRow: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  revenueCard: {
    flex: 1,
    borderRadius: Radii.lg,
    padding: Spacing.base,
    ...Shadow.md,
  },
  revLabel: { color: 'rgba(255,255,255,0.75)', fontSize: FontSize.xs, fontWeight: '600' },
  revAmount: { color: Colors.white, fontSize: FontSize.xl, fontWeight: '800', marginTop: 4 },
  revSub: { color: 'rgba(255,255,255,0.6)', fontSize: FontSize.xs, marginTop: 2 },

  sectionTitle: {
    color: Colors.textPrimary,
    fontSize: FontSize.base,
    fontWeight: '700',
    marginTop: Spacing.sm,
  },

  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  statCard: {
    width: '31%',
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
    borderTopWidth: 3,
    gap: 4,
  },
  statIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.xs,
  },
  statValue: {
    color: Colors.textPrimary,
    fontSize: FontSize.lg,
    fontWeight: '800',
  },
  statLabel: {
    color: Colors.textMuted,
    fontSize: 10,
    fontWeight: '600',
  },
  statSubtitle: {
    color: Colors.warning,
    fontSize: 9,
    fontWeight: '600',
  },

  quickActions: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  qaBtn: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    alignItems: 'center',
    gap: Spacing.xs,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  qaBtnText: {
    color: Colors.textSecondary,
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
  },

  recentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: Spacing.sm,
  },
  viewAllText: {
    color: Colors.accent,
    fontSize: FontSize.sm,
    fontWeight: '600',
  },

  bookingRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.md,
  },
  bookingLeft: { flex: 1, gap: 2 },
  bookingId: { color: Colors.accent, fontSize: FontSize.xs, fontWeight: '700' },
  bookingCustomer: { color: Colors.textPrimary, fontSize: FontSize.sm, fontWeight: '700' },
  bookingRoute: { color: Colors.textSecondary, fontSize: FontSize.xs },
  bookingDate: { color: Colors.textMuted, fontSize: FontSize.xs },
  bookingRight: {
    alignItems: 'flex-end',
    gap: Spacing.xs,
  },
  bookingAmount: { color: Colors.textPrimary, fontSize: FontSize.sm, fontWeight: '700' },
});
