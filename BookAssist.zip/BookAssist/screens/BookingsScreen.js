// screens/BookingsScreen.js
import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  RefreshControl,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import { fetchBookings } from '../services/dataService';
import AppHeader from '../components/AppHeader';
import StatusBadge from '../components/StatusBadge';
import EmptyState from '../components/EmptyState';
import LoadingScreen from '../components/LoadingScreen';
import {
  Colors,
  Spacing,
  Radii,
  FontSize,
  formatCurrency,
  formatDate,
} from '../utils/theme';
import {
  BOOKING_STATUS_COLORS,
  BOOKING_STATUS_LABELS,
  PAYMENT_STATUS_COLORS,
} from '../mock/bookings';

const FILTERS = ['all', 'pending', 'confirmed', 'on_trip', 'completed', 'cancelled'];

export default function BookingsScreen({ navigation }) {
  const { isDemoMode, user } = useApp();
  const [bookings, setBookings] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');

  const load = useCallback(async () => {
    try {
      const data = await fetchBookings(isDemoMode, user.companyId);
      setBookings(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [isDemoMode, user?.companyId]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    let result = bookings;
    if (activeFilter !== 'all') {
      result = result.filter(b => b.status === activeFilter);
    }
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        b =>
          b.customerName?.toLowerCase().includes(q) ||
          b.id?.toLowerCase().includes(q) ||
          b.driverName?.toLowerCase().includes(q) ||
          b.pickupLocation?.toLowerCase().includes(q) ||
          b.vehiclePlate?.toLowerCase().includes(q)
      );
    }
    setFiltered(result);
  }, [bookings, activeFilter, search]);

  if (loading) return <LoadingScreen message="Loading bookings..." />;

  const renderBooking = ({ item }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate('BookingDetail', { bookingId: item.id })}
    >
      <View style={styles.cardTop}>
        <View style={styles.cardLeft}>
          <Text style={styles.bookingId}>{item.id}</Text>
          <Text style={styles.customerName}>{item.customerName}</Text>
        </View>
        <View style={styles.cardRight}>
          <StatusBadge
            label={BOOKING_STATUS_LABELS[item.status]}
            color={BOOKING_STATUS_COLORS[item.status]}
          />
        </View>
      </View>

      <View style={styles.routeRow}>
        <Ionicons name="location" size={13} color={Colors.accent} />
        <Text style={styles.routeText} numberOfLines={1}>
          {item.pickupLocation}
        </Text>
        <Ionicons name="arrow-forward" size={13} color={Colors.textMuted} />
        <Text style={styles.routeText} numberOfLines={1}>
          {item.dropoffLocation}
        </Text>
      </View>

      <View style={styles.cardMeta}>
        <View style={styles.metaItem}>
          <Ionicons name="calendar" size={12} color={Colors.textMuted} />
          <Text style={styles.metaText}>{formatDate(item.startDate)}</Text>
        </View>
        {item.driverName && (
          <View style={styles.metaItem}>
            <Ionicons name="person" size={12} color={Colors.textMuted} />
            <Text style={styles.metaText}>{item.driverName}</Text>
          </View>
        )}
        {item.vehiclePlate && (
          <View style={styles.metaItem}>
            <Ionicons name="car" size={12} color={Colors.textMuted} />
            <Text style={styles.metaText}>{item.vehiclePlate}</Text>
          </View>
        )}
      </View>

      <View style={styles.cardBottom}>
        <View style={styles.metaItem}>
          <View
            style={[
              styles.payDot,
              { backgroundColor: PAYMENT_STATUS_COLORS[item.paymentStatus] },
            ]}
          />
          <Text style={[styles.payText, { color: PAYMENT_STATUS_COLORS[item.paymentStatus] }]}>
            {item.paymentStatus?.toUpperCase()}
          </Text>
        </View>
        <Text style={styles.amount}>{formatCurrency(item.finalAmount)}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <AppHeader
        rightAction={
          <TouchableOpacity
            style={styles.addBtn}
            onPress={() => navigation.navigate('NewBooking')}
          >
            <Ionicons name="add" size={20} color={Colors.white} />
          </TouchableOpacity>
        }
      />

      {/* Search */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={16} color={Colors.textMuted} />
        <TextInput
          style={styles.searchInput}
          value={search}
          onChangeText={setSearch}
          placeholder="Search bookings..."
          placeholderTextColor={Colors.textMuted}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Ionicons name="close-circle" size={16} color={Colors.textMuted} />
          </TouchableOpacity>
        )}
      </View>

      {/* Filter Tabs */}
      <FlatList
        data={FILTERS}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filters}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.filterTab, activeFilter === item && styles.filterTabActive]}
            onPress={() => setActiveFilter(item)}
          >
            <Text
              style={[
                styles.filterText,
                activeFilter === item && styles.filterTextActive,
              ]}
            >
              {item === 'all' ? 'All' : BOOKING_STATUS_LABELS[item]}
            </Text>
          </TouchableOpacity>
        )}
        style={styles.filterList}
      />

      {/* Count */}
      <Text style={styles.countText}>{filtered.length} booking{filtered.length !== 1 ? 's' : ''}</Text>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={renderBooking}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); load(); }} tintColor={Colors.accent} />
        }
        ListEmptyComponent={
          <EmptyState
            icon="calendar"
            title="No Bookings Found"
            subtitle="No bookings match your search or filter."
            actionLabel="New Booking"
            onAction={() => navigation.navigate('NewBooking')}
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.dark },
  addBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.accent,
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    margin: Spacing.base,
    borderRadius: Radii.lg,
    paddingHorizontal: Spacing.md,
    height: 44,
    gap: Spacing.sm,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  searchInput: {
    flex: 1,
    color: Colors.textPrimary,
    fontSize: FontSize.sm,
  },
  filterList: { marginBottom: Spacing.xs },
  filters: { paddingHorizontal: Spacing.base, gap: Spacing.sm },
  filterTab: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: Radii.full,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  filterTabActive: {
    backgroundColor: Colors.accent,
    borderColor: Colors.accent,
  },
  filterText: { color: Colors.textSecondary, fontSize: FontSize.xs, fontWeight: '600' },
  filterTextActive: { color: Colors.white },
  countText: {
    color: Colors.textMuted,
    fontSize: FontSize.xs,
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.xs,
  },
  list: { padding: Spacing.base, gap: Spacing.sm, paddingBottom: 80 },
  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.base,
    borderWidth: 1,
    borderColor: Colors.border,
    gap: Spacing.sm,
  },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  cardLeft: { gap: 2 },
  cardRight: {},
  bookingId: { color: Colors.accent, fontSize: FontSize.xs, fontWeight: '700' },
  customerName: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '700' },
  routeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
  },
  routeText: {
    color: Colors.textSecondary,
    fontSize: FontSize.xs,
    flex: 1,
  },
  cardMeta: { flexDirection: 'row', flexWrap: 'wrap', gap: Spacing.md },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  metaText: { color: Colors.textMuted, fontSize: FontSize.xs },
  cardBottom: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    paddingTop: Spacing.sm,
  },
  payDot: { width: 6, height: 6, borderRadius: 3 },
  payText: { fontSize: FontSize.xs, fontWeight: '700' },
  amount: { color: Colors.textPrimary, fontSize: FontSize.base, fontWeight: '800' },
});
