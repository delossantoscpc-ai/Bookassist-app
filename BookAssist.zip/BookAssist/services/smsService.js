// services/smsService.js
// In Demo Mode: returns formatted SMS strings for display
// In Live Mode: calls Firebase Cloud Function

export const buildSmsMessages = (booking, company) => {
  const template = company?.smsTemplate || {
    driver: 'New booking #{bookingId} for {customerName}. Pickup: {pickupLocation} on {date} at {time}.',
    customer: 'Your booking #{bookingId} is confirmed! Driver: {driverName} ({driverPhone}). Pickup: {pickupLocation} on {date} at {time}.',
  };

  const replacements = {
    '{bookingId}': booking.id,
    '{customerName}': booking.customerName,
    '{customerPhone}': booking.customerPhone,
    '{driverName}': booking.driverName || 'TBD',
    '{driverPhone}': booking.driverPhone || 'TBD',
    '{vehiclePlate}': booking.vehiclePlate || 'TBD',
    '{vehicleName}': booking.vehicleName || 'TBD',
    '{pickupLocation}': booking.pickupLocation,
    '{dropoffLocation}': booking.dropoffLocation,
    '{date}': booking.startDate,
    '{time}': booking.startTime,
    '{companyPhone}': company?.phone || '',
    '{companyName}': company?.name || 'BookAssist',
  };

  const interpolate = (template) =>
    Object.entries(replacements).reduce(
      (str, [key, val]) => str.replaceAll(key, val),
      template
    );

  return {
    driverSms: {
      to: booking.driverPhone,
      toName: booking.driverName,
      body: interpolate(template.driver),
    },
    customerSms: {
      to: booking.customerPhone,
      toName: booking.customerName,
      body: interpolate(template.customer),
    },
  };
};

export const sendConfirmationSms = async (isDemoMode, booking, company) => {
  const messages = buildSmsMessages(booking, company);

  if (isDemoMode) {
    // Don't send real SMS — return preview data for modal
    return { demo: true, messages };
  }

  // Live Mode: call Firebase Cloud Function
  try {
    const { getFunctions, httpsCallable } = await import('firebase/functions');
    const { app } = await import('../firebase/config');
    const functions = getFunctions(app, 'asia-southeast1');
    const sendSms = httpsCallable(functions, 'sendBookingConfirmation');
    const result = await sendSms({
      bookingId: booking.id,
      driverPhone: booking.driverPhone,
      customerPhone: booking.customerPhone,
      driverMessage: messages.driverSms.body,
      customerMessage: messages.customerSms.body,
    });
    return { demo: false, success: result.data.success, messages };
  } catch (error) {
    throw new Error(`SMS send failed: ${error.message}`);
  }
};
