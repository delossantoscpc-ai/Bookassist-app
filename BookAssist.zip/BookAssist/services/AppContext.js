// services/AppContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { authenticateDemo } from '../mock/users';
import { getCompanyById } from '../mock/companies';

const AppContext = createContext(null);

export const AppProvider = ({ children }) => {
  const [isDemoMode, setIsDemoMode] = useState(true);
  const [user, setUser] = useState(null);
  const [company, setCompany] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPersistedState();
  }, []);

  const loadPersistedState = async () => {
    try {
      const mode = await AsyncStorage.getItem('isDemoMode');
      const savedUser = await AsyncStorage.getItem('user');
      if (mode !== null) setIsDemoMode(JSON.parse(mode));
      if (savedUser) {
        const parsedUser = JSON.parse(savedUser);
        setUser(parsedUser);
        const comp = getCompanyById(parsedUser.companyId);
        setCompany(comp);
      }
    } catch (e) {
      console.log('State load error', e);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleMode = async () => {
    const newMode = !isDemoMode;
    setIsDemoMode(newMode);
    await AsyncStorage.setItem('isDemoMode', JSON.stringify(newMode));
    // Sign out when switching modes
    await signOut();
  };

  const signIn = async (email, password) => {
    if (isDemoMode) {
      const demoUser = authenticateDemo(email, password);
      if (!demoUser) throw new Error('Invalid credentials. Try demo accounts below.');
      const { password: _, ...safeUser } = demoUser;
      setUser(safeUser);
      const comp = getCompanyById(safeUser.companyId);
      setCompany(comp);
      await AsyncStorage.setItem('user', JSON.stringify(safeUser));
      return safeUser;
    } else {
      // Firebase auth - import dynamically to avoid crashes in demo
      const { signInWithEmailAndPassword } = await import('firebase/auth');
      const { auth } = await import('../firebase/config');
      const result = await signInWithEmailAndPassword(auth, email, password);
      // Fetch user doc from Firestore
      const { doc, getDoc } = await import('firebase/firestore');
      const { db } = await import('../firebase/config');
      const userDoc = await getDoc(doc(db, 'users', result.user.uid));
      const userData = { id: result.user.uid, ...userDoc.data() };
      setUser(userData);
      const comp = await fetchFirestoreCompany(userData.companyId);
      setCompany(comp);
      await AsyncStorage.setItem('user', JSON.stringify(userData));
      return userData;
    }
  };

  const fetchFirestoreCompany = async (companyId) => {
    const { doc, getDoc } = await import('firebase/firestore');
    const { db } = await import('../firebase/config');
    const compDoc = await getDoc(doc(db, 'companies', companyId));
    return { id: compDoc.id, ...compDoc.data() };
  };

  const signOut = async () => {
    setUser(null);
    setCompany(null);
    await AsyncStorage.removeItem('user');
    if (!isDemoMode) {
      try {
        const { signOut: fbSignOut } = await import('firebase/auth');
        const { auth } = await import('../firebase/config');
        await fbSignOut(auth);
      } catch (e) {}
    }
  };

  return (
    <AppContext.Provider
      value={{
        isDemoMode,
        toggleMode,
        user,
        company,
        signIn,
        signOut,
        isLoading,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
