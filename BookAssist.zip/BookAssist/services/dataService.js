// services/dataService.js
// Unified data layer: returns mock data in Demo Mode, Firestore in Live Mode

import {
  MOCK_BOOKINGS,
  getBookingsByCompany,
  getBookingById,
} from '../mock/bookings';
import {
  MOCK_VEHICLES,
  getVehiclesByCompany,
  getVehicleById,
} from '../mock/vehicles';
import {
  MOCK_DRIVERS,
  getDriversByCompany,
  getDriverById,
} from '../mock/drivers';
import {
  MOCK_CUSTOMERS,
  getCustomersByCompany,
  getCustomerById,
} from '../mock/customers';

// In-memory mutable store for demo mode
let demoStore = {
  bookings: [...MOCK_BOOKINGS],
  vehicles: [...MOCK_VEHICLES],
  drivers: [...MOCK_DRIVERS],
  customers: [...MOCK_CUSTOMERS],
};

const generateId = (prefix) => `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
const generateBookingId = () => {
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
  const rand = Math.floor(Math.random() * 900 + 100);
  return `BK-${dateStr}-${rand}`;
};

// ─── BOOKINGS ──────────────────────────────────────────────────────
export const fetchBookings = async (isDemoMode, companyId) => {
  if (isDemoMode) {
    return demoStore.bookings.filter(b => b.companyId === companyId);
  }
  const { collection, query, where, getDocs, orderBy } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  const q = query(
    collection(db, 'bookings'),
    where('companyId', '==', companyId),
    orderBy('createdAt', 'desc')
  );
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

export const fetchBookingById = async (isDemoMode, bookingId) => {
  if (isDemoMode) {
    return demoStore.bookings.find(b => b.id === bookingId) || null;
  }
  const { doc, getDoc } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  const snap = await getDoc(doc(db, 'bookings', bookingId));
  return snap.exists() ? { id: snap.id, ...snap.data() } : null;
};

export const createBooking = async (isDemoMode, bookingData) => {
  const id = generateBookingId();
  const newBooking = {
    ...bookingData,
    id,
    status: 'pending',
    paymentStatus: 'unpaid',
    smsDriverSent: false,
    smsCustomerSent: false,
    createdAt: new Date().toISOString().slice(0, 10),
  };
  if (isDemoMode) {
    demoStore.bookings.unshift(newBooking);
    return newBooking;
  }
  const { collection, addDoc } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  const ref = await addDoc(collection(db, 'bookings'), newBooking);
  return { id: ref.id, ...newBooking };
};

export const updateBooking = async (isDemoMode, bookingId, updates) => {
  if (isDemoMode) {
    const idx = demoStore.bookings.findIndex(b => b.id === bookingId);
    if (idx !== -1) {
      demoStore.bookings[idx] = { ...demoStore.bookings[idx], ...updates };
      return demoStore.bookings[idx];
    }
    return null;
  }
  const { doc, updateDoc } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  await updateDoc(doc(db, 'bookings', bookingId), updates);
  return { id: bookingId, ...updates };
};

export const confirmBooking = async (isDemoMode, bookingId) => {
  const updates = {
    status: 'confirmed',
    confirmedAt: new Date().toISOString().slice(0, 10),
    smsDriverSent: true,
    smsCustomerSent: true,
  };
  return updateBooking(isDemoMode, bookingId, updates);
};

// ─── VEHICLES ──────────────────────────────────────────────────────
export const fetchVehicles = async (isDemoMode, companyId) => {
  if (isDemoMode) {
    return demoStore.vehicles.filter(v => v.companyId === companyId);
  }
  const { collection, query, where, getDocs } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  const q = query(collection(db, 'vehicles'), where('companyId', '==', companyId));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

export const updateVehicle = async (isDemoMode, vehicleId, updates) => {
  if (isDemoMode) {
    const idx = demoStore.vehicles.findIndex(v => v.id === vehicleId);
    if (idx !== -1) {
      demoStore.vehicles[idx] = { ...demoStore.vehicles[idx], ...updates };
      return demoStore.vehicles[idx];
    }
    return null;
  }
  const { doc, updateDoc } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  await updateDoc(doc(db, 'vehicles', vehicleId), updates);
  return { id: vehicleId, ...updates };
};

export const addVehicle = async (isDemoMode, companyId, vehicleData) => {
  const id = generateId('veh');
  const newVehicle = { ...vehicleData, id, companyId, status: 'available' };
  if (isDemoMode) {
    demoStore.vehicles.push(newVehicle);
    return newVehicle;
  }
  const { collection, addDoc } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  const ref = await addDoc(collection(db, 'vehicles'), newVehicle);
  return { id: ref.id, ...newVehicle };
};

// ─── DRIVERS ───────────────────────────────────────────────────────
export const fetchDrivers = async (isDemoMode, companyId) => {
  if (isDemoMode) {
    return demoStore.drivers.filter(d => d.companyId === companyId);
  }
  const { collection, query, where, getDocs } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  const q = query(collection(db, 'drivers'), where('companyId', '==', companyId));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

export const updateDriver = async (isDemoMode, driverId, updates) => {
  if (isDemoMode) {
    const idx = demoStore.drivers.findIndex(d => d.id === driverId);
    if (idx !== -1) {
      demoStore.drivers[idx] = { ...demoStore.drivers[idx], ...updates };
      return demoStore.drivers[idx];
    }
    return null;
  }
  const { doc, updateDoc } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  await updateDoc(doc(db, 'drivers', driverId), updates);
  return { id: driverId, ...updates };
};

export const addDriver = async (isDemoMode, companyId, driverData) => {
  const id = generateId('drv');
  const newDriver = { ...driverData, id, companyId, status: 'available', totalTrips: 0, rating: 5.0 };
  if (isDemoMode) {
    demoStore.drivers.push(newDriver);
    return newDriver;
  }
  const { collection, addDoc } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  const ref = await addDoc(collection(db, 'drivers'), newDriver);
  return { id: ref.id, ...newDriver };
};

// ─── CUSTOMERS ─────────────────────────────────────────────────────
export const fetchCustomers = async (isDemoMode, companyId) => {
  if (isDemoMode) {
    return demoStore.customers.filter(c => c.companyId === companyId);
  }
  const { collection, query, where, getDocs } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  const q = query(collection(db, 'customers'), where('companyId', '==', companyId));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
};

export const addCustomer = async (isDemoMode, companyId, customerData) => {
  const id = generateId('cust');
  const newCustomer = {
    ...customerData,
    id,
    companyId,
    totalBookings: 0,
    totalSpent: 0,
    status: 'active',
    createdAt: new Date().toISOString().slice(0, 10),
  };
  if (isDemoMode) {
    demoStore.customers.push(newCustomer);
    return newCustomer;
  }
  const { collection, addDoc } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  const ref = await addDoc(collection(db, 'customers'), newCustomer);
  return { id: ref.id, ...newCustomer };
};

export const updateCustomer = async (isDemoMode, customerId, updates) => {
  if (isDemoMode) {
    const idx = demoStore.customers.findIndex(c => c.id === customerId);
    if (idx !== -1) {
      demoStore.customers[idx] = { ...demoStore.customers[idx], ...updates };
      return demoStore.customers[idx];
    }
    return null;
  }
  const { doc, updateDoc } = await import('firebase/firestore');
  const { db } = await import('../firebase/config');
  await updateDoc(doc(db, 'customers', customerId), updates);
  return { id: customerId, ...updates };
};

// ─── DASHBOARD STATS ───────────────────────────────────────────────
export const fetchDashboardStats = async (isDemoMode, companyId) => {
  const [bookings, vehicles, drivers, customers] = await Promise.all([
    fetchBookings(isDemoMode, companyId),
    fetchVehicles(isDemoMode, companyId),
    fetchDrivers(isDemoMode, companyId),
    fetchCustomers(isDemoMode, companyId),
  ]);

  const today = new Date().toISOString().slice(0, 10);

  const activeBookings = bookings.filter(b =>
    ['confirmed', 'on_trip'].includes(b.status)
  ).length;

  const pendingBookings = bookings.filter(b => b.status === 'pending').length;

  const availableVehicles = vehicles.filter(v => v.status === 'available').length;

  const availableDrivers = drivers.filter(d => d.status === 'available').length;

  const todayBookings = bookings.filter(b => b.startDate === today).length;

  const totalRevenue = bookings
    .filter(b => b.paymentStatus === 'paid')
    .reduce((sum, b) => sum + (b.finalAmount || 0), 0);

  const monthRevenue = bookings
    .filter(b => {
      const month = new Date().toISOString().slice(0, 7);
      return b.createdAt?.startsWith(month) && b.paymentStatus === 'paid';
    })
    .reduce((sum, b) => sum + (b.finalAmount || 0), 0);

  const recentBookings = [...bookings]
    .sort((a, b) => b.createdAt?.localeCompare(a.createdAt))
    .slice(0, 5);

  return {
    activeBookings,
    pendingBookings,
    availableVehicles,
    totalVehicles: vehicles.length,
    availableDrivers,
    totalDrivers: drivers.length,
    totalCustomers: customers.length,
    todayBookings,
    totalRevenue,
    monthRevenue,
    recentBookings,
  };
};
