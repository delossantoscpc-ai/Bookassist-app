# BookAssist 🚗
### Car Rental Operations Platform

A full-featured React Native + Expo mobile app for car rental office staff. Supports multiple companies with their own branding, and features a Demo Mode with local mock data so you can explore the entire app without any backend.

---

## ✨ Features

| Feature | Demo Mode | Live Mode |
|---|---|---|
| Dashboard with KPIs | ✅ Mock data | ✅ Firebase |
| Booking management | ✅ | ✅ |
| Vehicle fleet tracking | ✅ | ✅ |
| Driver management | ✅ | ✅ |
| Customer records | ✅ | ✅ |
| Payment tracking | ✅ | ✅ |
| Reports & analytics | ✅ | ✅ |
| SMS notifications | 📱 Preview modal | 📨 Real SMS |
| Multi-tenant / company | ✅ 3 companies | ✅ Firebase |
| Company branding | ✅ | ✅ |

---

## 📁 Project Structure

```
BookAssist/
├── App.js                      # Entry point
├── app.json                    # Expo config
├── package.json
├── firebase.json               # Firebase project config
├── firestore.rules             # Firestore security rules
│
├── mock/                       # 📦 Demo Mode data
│   ├── companies.js            # 3 sample companies with branding
│   ├── bookings.js             # 8 sample bookings
│   ├── vehicles.js             # 8 sample vehicles
│   ├── drivers.js              # 7 sample drivers
│   ├── customers.js            # 8 sample customers
│   └── users.js                # 3 demo login accounts
│
├── services/
│   ├── AppContext.js           # Global state: mode, auth, company
│   ├── dataService.js          # Unified data API (mock ↔ Firebase)
│   └── smsService.js           # SMS: preview modal or real send
│
├── firebase/
│   └── config.js               # Firebase project credentials
│
├── navigation/
│   └── AppNavigator.js         # Bottom tabs + stack navigation
│
├── screens/
│   ├── LoginScreen.js          # Login + demo account shortcuts
│   ├── DashboardScreen.js      # KPIs, quick actions, recent bookings
│   ├── BookingsScreen.js       # List with search + filter
│   ├── BookingDetailScreen.js  # Full detail + confirm + SMS
│   ├── NewBookingScreen.js     # Create booking form
│   ├── VehiclesScreen.js       # Fleet management
│   ├── DriversScreen.js        # Driver management
│   ├── CustomersScreen.js      # Customer records
│   ├── ReportsScreen.js        # Revenue & analytics
│   └── SettingsScreen.js       # Profile, mode toggle, company info
│
├── components/
│   ├── AppHeader.js            # Header with company logo + name
│   ├── StatusBadge.js          # Colored status pill
│   ├── SmsPreviewModal.js      # Demo Mode SMS preview popup
│   ├── ModeToggle.js           # Demo ↔ Live mode switch
│   ├── LoadingScreen.js
│   └── EmptyState.js
│
├── utils/
│   └── theme.js                # Colors, spacing, typography, helpers
│
└── functions/                  # Firebase Cloud Functions (Live Mode SMS)
    ├── package.json
    └── src/
        └── index.js            # sendBookingConfirmation function
```

---

## 🚀 Quick Start — Demo Mode (Expo Go)

> **No Firebase or backend required!** Demo Mode works 100% offline with local data.

### Prerequisites

- Node.js 18+
- Expo Go app on your phone ([iOS](https://apps.apple.com/app/expo-go/id982107779) / [Android](https://play.google.com/store/apps/details?id=host.exp.exponent))

### Steps

```bash
# 1. Install dependencies
cd BookAssist
npm install

# 2. Start the dev server
npx expo start

# 3. Scan the QR code with Expo Go on your phone
```

Then log in with any of the **3 demo accounts** (tap to auto-fill):

| Company | Email | Password |
|---|---|---|
| 🚗 Cebu Premier Rentals | admin@cebupremiertentals.ph | demo123 |
| 🏎️ Visayas AutoLease | admin@visayasautolease.ph | demo123 |
| 🌴 Island Wheels Corp | admin@islandwheels.ph | demo123 |

---

## 📱 Running on Android Emulator

### Prerequisites

- Android Studio with an AVD (Android Virtual Device) set up
- `ANDROID_HOME` environment variable configured

### Steps

```bash
# 1. Open Android Studio and start your emulator
# Go to: Tools → Device Manager → ▶ (play button)

# 2. Install dependencies
npm install

# 3. Start Expo with Android target
npx expo start --android

# OR if Expo is already running, press 'a' in the terminal
```

**Troubleshooting:**
```bash
# If emulator not detected:
adb devices                          # Should list your emulator
adb reverse tcp:8081 tcp:8081        # Fix Metro connection

# Reset Expo cache if app won't load:
npx expo start --clear
```

---

## 🍎 Running on iOS Simulator (macOS only)

```bash
# Requires Xcode installed
npx expo start --ios
```

---

## 🔥 Setting Up Live Mode (Firebase)

### Step 1 — Create Firebase Project

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Create a new project (e.g. `bookassist-prod`)
3. Enable **Authentication** → Email/Password
4. Enable **Firestore Database** (start in test mode)
5. Register a Web App → copy the config object

### Step 2 — Configure the App

Edit `firebase/config.js` and replace the placeholder values:

```js
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "bookassist-xxx.firebaseapp.com",
  projectId: "bookassist-xxx",
  storageBucket: "bookassist-xxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc..."
};
```

### Step 3 — Deploy Firestore Rules

```bash
npm install -g firebase-tools
firebase login
firebase use --add          # Select your project
firebase deploy --only firestore:rules
```

### Step 4 — Seed Initial Data

Create user accounts in Firebase Auth, then add corresponding Firestore documents:

**Collection: `users/{uid}`**
```json
{
  "name": "Your Name",
  "email": "you@company.com",
  "role": "admin",
  "companyId": "company_001"
}
```

**Collection: `companies/{companyId}`**
```json
{
  "name": "My Car Rental Company",
  "logoEmoji": "🚗",
  "logoColor": "#1E40AF",
  "accentColor": "#3B82F6",
  "phone": "+63 32 123 4567",
  "smsTemplate": {
    "driver": "New booking #{bookingId} ...",
    "customer": "Your booking #{bookingId} is confirmed..."
  }
}
```

### Step 5 — Toggle to Live Mode

In the app → Settings tab → toggle **Demo → Live**

---

## 📨 Enabling Real SMS (Cloud Functions)

### For Philippines (Semaphore — Recommended)

```bash
cd functions
npm install

# Set your Semaphore API key
firebase functions:config:set semaphore.api_key="YOUR_SEMAPHORE_KEY"
firebase functions:config:set semaphore.sender_name="BookAssist"

# Deploy
firebase deploy --only functions
```

### For International (Twilio)

```bash
firebase functions:config:set twilio.account_sid="ACxxx"
firebase functions:config:set twilio.auth_token="xxx"
firebase functions:config:set twilio.from="+1234567890"

firebase deploy --only functions
```

---

## 🎭 Demo Mode Details

### What Demo Mode Does

- ✅ Uses local JavaScript arrays as the database
- ✅ All CRUD operations work (create booking, update status, etc.)
- ✅ State persists within the session (bookings you create appear in lists)
- ✅ SMS confirmation shows a **preview modal** instead of sending real messages
- ✅ Shows exactly what would be sent to driver and customer
- ❌ No network calls
- ❌ Data resets when you restart the app (no persistence between sessions)

### SMS Preview Modal

When you confirm a booking in Demo Mode, instead of sending SMS:

1. The booking status updates to **Confirmed**
2. A modal pops up showing:
   - 📱 **SMS to Driver** — with their phone number and the full message
   - 📱 **SMS to Customer** — with their phone number and the full message
   - Character count for each message
   - Note explaining how to enable real SMS

### Mock Data Summary

**3 Companies:**
- 🚗 Cebu Premier Rentals — Blue branding, Cebu City
- 🏎️ Visayas AutoLease — Green branding, Capitol Site
- 🌴 Island Wheels Corp — Amber branding, Banilad

**Per Company:**
- 2–4 vehicles (SUVs, sedans, vans, pickups)
- 2–3 drivers with ratings and trip history
- 2–4 customers (mix of local and foreign)
- 2–3 bookings (pending, confirmed, on trip, completed, cancelled)

---

## 🏗️ Architecture Notes

### Multi-Tenancy

Each user has a `companyId`. All data queries filter by this ID. Company branding (logo emoji, colors, name) is loaded dynamically into the header.

### Data Service Pattern

`services/dataService.js` is the single source of truth for all data operations. Every function accepts `isDemoMode` as its first parameter:

```js
// Same call works in both modes
const bookings = await fetchBookings(isDemoMode, companyId);
const booking = await createBooking(isDemoMode, bookingData);
await confirmBooking(isDemoMode, bookingId);
```

### SMS Service Pattern

```js
const result = await sendConfirmationSms(isDemoMode, booking, company);

if (result.demo) {
  // Show SmsPreviewModal with result.messages
} else {
  // Real SMS sent via Cloud Function
}
```

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Framework | React Native + Expo SDK 51 |
| Navigation | React Navigation v6 (Bottom Tabs + Stack) |
| Auth | Firebase Authentication |
| Database | Cloud Firestore |
| SMS (Live) | Firebase Cloud Functions + Semaphore/Twilio |
| State | React Context + hooks |
| Storage | AsyncStorage (session persistence) |
| Icons | @expo/vector-icons (Ionicons) |
| Gradients | expo-linear-gradient |

---

## 📝 License

MIT — build your own car rental empire 🚗
