// mock/companies.js
// Demo data for 3 companies with full branding

export const MOCK_COMPANIES = [
  {
    id: 'company_001',
    name: 'Cebu Premier Rentals',
    shortName: 'CPR',
    logoEmoji: '🚗',
    logoColor: '#1E40AF',
    accentColor: '#3B82F6',
    primaryColor: '#0F172A',
    tagline: 'Your ride, our pride',
    address: 'F. Ramos St, Cebu City, 6000',
    phone: '+63 32 123 4567',
    email: 'ops@cebupremiertentals.ph',
    smsTemplate: {
      driver: 'Hi {driverName}, you have a new booking #{bookingId}. Pick up {customerName} at {pickupLocation} on {date} at {time}. - CPR',
      customer: 'Hi {customerName}, your CPR booking #{bookingId} is confirmed! Driver: {driverName} ({driverPhone}). Pickup: {pickupLocation} on {date} at {time}.',
    },
    active: true,
  },
  {
    id: 'company_002',
    name: 'Visayas AutoLease',
    shortName: 'VAL',
    logoEmoji: '🏎️',
    logoColor: '#065F46',
    accentColor: '#10B981',
    primaryColor: '#064E3B',
    tagline: 'Drive the difference',
    address: 'Capitol Site, Cebu City, 6000',
    phone: '+63 32 987 6543',
    email: 'bookings@visayasautolease.ph',
    smsTemplate: {
      driver: 'VAL Booking #{bookingId}: {customerName} pickup at {pickupLocation} on {date} {time}. Contact: {customerPhone}',
      customer: 'VAL Booking Confirmed! #{bookingId} - {driverName} will pick you up at {pickupLocation} on {date} at {time}. Questions? Call {companyPhone}',
    },
    active: true,
  },
  {
    id: 'company_003',
    name: 'Island Wheels Corp',
    shortName: 'IWC',
    logoEmoji: '🌴',
    logoColor: '#92400E',
    accentColor: '#F59E0B',
    primaryColor: '#1C1917',
    tagline: 'Explore every island',
    address: 'Banilad, Cebu City, 6000',
    phone: '+63 32 555 8888',
    email: 'rentals@islandwheels.ph',
    smsTemplate: {
      driver: '🌴 IWC Alert: New trip #{bookingId}. Customer: {customerName} @ {pickupLocation}, {date} {time}. Plate: {vehiclePlate}',
      customer: '🌴 Island Wheels: Booking #{bookingId} confirmed! Your driver {driverName} ({driverPhone}) picks you up at {pickupLocation} on {date} at {time}. Safe travels!',
    },
    active: true,
  },
];

export const getCompanyById = (id) => MOCK_COMPANIES.find(c => c.id === id);
