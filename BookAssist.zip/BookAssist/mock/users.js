// mock/users.js
// Demo user accounts - one per company

export const MOCK_USERS = [
  {
    id: 'user_001',
    email: 'admin@cebupremiertentals.ph',
    password: 'demo123',
    name: 'Alex Rivera',
    role: 'admin',
    companyId: 'company_001',
    companyName: 'Cebu Premier Rentals',
  },
  {
    id: 'user_002',
    email: 'admin@visayasautolease.ph',
    password: 'demo123',
    name: 'Carmen Uy',
    role: 'admin',
    companyId: 'company_002',
    companyName: 'Visayas AutoLease',
  },
  {
    id: 'user_003',
    email: 'admin@islandwheels.ph',
    password: 'demo123',
    name: 'Ben Reyes',
    role: 'admin',
    companyId: 'company_003',
    companyName: 'Island Wheels Corp',
  },
];

export const authenticateDemo = (email, password) => {
  return MOCK_USERS.find(
    u => u.email.toLowerCase() === email.toLowerCase() && u.password === password
  );
};
