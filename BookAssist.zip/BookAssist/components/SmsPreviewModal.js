// components/SmsPreviewModal.js
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, Radii, FontSize, Shadow } from '../utils/theme';

export default function SmsPreviewModal({ visible, smsData, onClose }) {
  if (!smsData) return null;

  const { driverSms, customerSms } = smsData;

  return (
    <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.sheet}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.demoPill}>
              <Ionicons name="flask" size={12} color={Colors.demoText} />
              <Text style={styles.demoLabel}>DEMO MODE — SMS Preview</Text>
            </View>
            <TouchableOpacity onPress={onClose} style={styles.closeBtn}>
              <Ionicons name="close" size={20} color={Colors.textPrimary} />
            </TouchableOpacity>
          </View>

          <Text style={styles.subtitle}>
            In Live Mode, these messages would be sent via SMS. In Demo Mode, they are shown here only.
          </Text>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Driver SMS */}
            <View style={styles.smsCard}>
              <View style={styles.smsHeader}>
                <View style={[styles.smsIcon, { backgroundColor: Colors.accent + '22' }]}>
                  <Ionicons name="car" size={18} color={Colors.accent} />
                </View>
                <View style={styles.smsTo}>
                  <Text style={styles.smsLabel}>SMS to Driver</Text>
                  <Text style={styles.smsRecipient}>{driverSms?.toName} • {driverSms?.to}</Text>
                </View>
                <View style={styles.simBadge}>
                  <Text style={styles.simText}>SIMULATED</Text>
                </View>
              </View>
              <View style={styles.smsBubble}>
                <Text style={styles.smsBody}>{driverSms?.body}</Text>
              </View>
              <View style={styles.charCount}>
                <Text style={styles.charText}>{driverSms?.body?.length || 0} characters</Text>
              </View>
            </View>

            {/* Customer SMS */}
            <View style={styles.smsCard}>
              <View style={styles.smsHeader}>
                <View style={[styles.smsIcon, { backgroundColor: Colors.success + '22' }]}>
                  <Ionicons name="person" size={18} color={Colors.success} />
                </View>
                <View style={styles.smsTo}>
                  <Text style={styles.smsLabel}>SMS to Customer</Text>
                  <Text style={styles.smsRecipient}>{customerSms?.toName} • {customerSms?.to}</Text>
                </View>
                <View style={styles.simBadge}>
                  <Text style={styles.simText}>SIMULATED</Text>
                </View>
              </View>
              <View style={styles.smsBubble}>
                <Text style={styles.smsBody}>{customerSms?.body}</Text>
              </View>
              <View style={styles.charCount}>
                <Text style={styles.charText}>{customerSms?.body?.length || 0} characters</Text>
              </View>
            </View>

            <View style={styles.notice}>
              <Ionicons name="information-circle" size={16} color={Colors.warning} />
              <Text style={styles.noticeText}>
                To enable real SMS, switch to Live Mode and configure Firebase Cloud Functions with Twilio or Semaphore.
              </Text>
            </View>
          </ScrollView>

          <TouchableOpacity style={styles.doneBtn} onPress={onClose}>
            <Text style={styles.doneBtnText}>Got it, close</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: Colors.surface,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: Spacing.xl,
    maxHeight: '85%',
    ...Shadow.lg,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: Spacing.sm,
  },
  demoPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.demoBg,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: Radii.full,
  },
  demoLabel: {
    color: Colors.demoText,
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  closeBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.dark,
    justifyContent: 'center',
    alignItems: 'center',
  },
  subtitle: {
    color: Colors.textSecondary,
    fontSize: FontSize.xs,
    lineHeight: 18,
    marginBottom: Spacing.base,
  },
  smsCard: {
    backgroundColor: Colors.dark,
    borderRadius: Radii.lg,
    padding: Spacing.base,
    marginBottom: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  smsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  smsIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  smsTo: {
    flex: 1,
  },
  smsLabel: {
    color: Colors.textPrimary,
    fontSize: FontSize.sm,
    fontWeight: '700',
  },
  smsRecipient: {
    color: Colors.textMuted,
    fontSize: FontSize.xs,
    marginTop: 1,
  },
  simBadge: {
    backgroundColor: Colors.warning + '22',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: Radii.sm,
    borderWidth: 1,
    borderColor: Colors.warning + '44',
  },
  simText: {
    color: Colors.warning,
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  smsBubble: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.md,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  smsBody: {
    color: Colors.textPrimary,
    fontSize: FontSize.sm,
    lineHeight: 20,
  },
  charCount: {
    alignItems: 'flex-end',
    marginTop: Spacing.xs,
  },
  charText: {
    color: Colors.textMuted,
    fontSize: 10,
  },
  notice: {
    flexDirection: 'row',
    gap: Spacing.sm,
    backgroundColor: Colors.warning + '11',
    borderRadius: Radii.md,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.warning + '33',
    marginBottom: Spacing.base,
  },
  noticeText: {
    color: Colors.warning,
    fontSize: FontSize.xs,
    flex: 1,
    lineHeight: 18,
  },
  doneBtn: {
    backgroundColor: Colors.accent,
    borderRadius: Radii.lg,
    padding: Spacing.base,
    alignItems: 'center',
    marginTop: Spacing.sm,
  },
  doneBtnText: {
    color: Colors.white,
    fontSize: FontSize.base,
    fontWeight: '700',
  },
});
