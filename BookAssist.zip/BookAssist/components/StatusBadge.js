// components/StatusBadge.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors, Radii, FontSize } from '../utils/theme';

export default function StatusBadge({ label, color, size = 'sm' }) {
  const textSize = size === 'lg' ? FontSize.sm : 10;
  const pad = size === 'lg' ? { paddingHorizontal: 12, paddingVertical: 5 } : { paddingHorizontal: 8, paddingVertical: 3 };

  return (
    <View style={[styles.badge, pad, { backgroundColor: color + '22', borderColor: color + '55' }]}>
      <View style={[styles.dot, { backgroundColor: color }]} />
      <Text style={[styles.label, { color, fontSize: textSize }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: Radii.full,
    borderWidth: 1,
    gap: 4,
    alignSelf: 'flex-start',
  },
  dot: {
    width: 5,
    height: 5,
    borderRadius: 3,
  },
  label: {
    fontWeight: '700',
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
});
