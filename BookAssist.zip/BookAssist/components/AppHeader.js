// components/AppHeader.js
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useApp } from '../services/AppContext';
import { Colors, Spacing, FontSize } from '../utils/theme';
import { Ionicons } from '@expo/vector-icons';

export default function AppHeader({ title, showBack, onBack, rightAction }) {
  const { company, isDemoMode } = useApp();

  return (
    <View style={styles.container}>
      <View style={styles.left}>
        {showBack ? (
          <TouchableOpacity onPress={onBack} style={styles.backBtn}>
            <Ionicons name="chevron-back" size={22} color={Colors.textPrimary} />
          </TouchableOpacity>
        ) : (
          <View style={styles.logoContainer}>
            <View style={[styles.logoBox, { backgroundColor: company?.logoColor || Colors.accent }]}>
              <Text style={styles.logoEmoji}>{company?.logoEmoji || '🚗'}</Text>
            </View>
            <View style={styles.logoText}>
              <Text style={styles.companyName} numberOfLines={1}>
                {company?.name || 'BookAssist'}
              </Text>
              <Text style={styles.appLabel}>BookAssist</Text>
            </View>
          </View>
        )}
      </View>

      {title && showBack && (
        <Text style={styles.screenTitle} numberOfLines={1}>{title}</Text>
      )}

      <View style={styles.right}>
        {isDemoMode && (
          <View style={styles.demoBadge}>
            <Text style={styles.demoText}>DEMO</Text>
          </View>
        )}
        {rightAction && rightAction}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.base,
    paddingVertical: Spacing.sm + 2,
    backgroundColor: Colors.darker,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
    minHeight: 60,
  },
  left: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  logoBox: {
    width: 38,
    height: 38,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoEmoji: {
    fontSize: 20,
  },
  logoText: {
    gap: 1,
  },
  companyName: {
    color: Colors.textPrimary,
    fontSize: FontSize.sm,
    fontWeight: '700',
    maxWidth: 160,
  },
  appLabel: {
    color: Colors.textMuted,
    fontSize: 10,
    fontWeight: '500',
    letterSpacing: 0.5,
  },
  screenTitle: {
    color: Colors.textPrimary,
    fontSize: FontSize.base,
    fontWeight: '600',
    flex: 1,
    textAlign: 'center',
  },
  right: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: Spacing.sm,
  },
  demoBadge: {
    backgroundColor: Colors.demoBg,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 3,
    borderRadius: 6,
  },
  demoText: {
    color: Colors.demoText,
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 1,
  },
});
