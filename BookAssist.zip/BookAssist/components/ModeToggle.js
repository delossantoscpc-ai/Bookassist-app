// components/ModeToggle.js
import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  TouchableOpacity,
  Modal,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useApp } from '../services/AppContext';
import { Colors, Spacing, Radii, FontSize } from '../utils/theme';

export default function ModeToggle() {
  const { isDemoMode, toggleMode } = useApp();
  const [showInfo, setShowInfo] = useState(false);

  const handleToggle = () => {
    Alert.alert(
      isDemoMode ? 'Switch to Live Mode?' : 'Switch to Demo Mode?',
      isDemoMode
        ? 'Live Mode connects to Firebase. You need a valid Firebase config and credentials.'
        : 'Demo Mode uses local mock data. No external APIs are called.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Switch',
          onPress: toggleMode,
        },
      ]
    );
  };

  return (
    <>
      <TouchableOpacity style={styles.container} onPress={handleToggle} activeOpacity={0.8}>
        <View style={[styles.indicator, { backgroundColor: isDemoMode ? Colors.demoBg : Colors.success }]}>
          <Ionicons
            name={isDemoMode ? 'flask' : 'cloud'}
            size={12}
            color={Colors.white}
          />
        </View>
        <Text style={styles.label}>
          {isDemoMode ? 'Demo' : 'Live'}
        </Text>
        <Switch
          value={!isDemoMode}
          onValueChange={handleToggle}
          trackColor={{ false: Colors.demoBg + '80', true: Colors.success + '80' }}
          thumbColor={isDemoMode ? Colors.demoText : Colors.success}
          style={{ transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }] }}
        />
      </TouchableOpacity>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    backgroundColor: Colors.surface,
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: Radii.full,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  indicator: {
    width: 18,
    height: 18,
    borderRadius: 9,
    justifyContent: 'center',
    alignItems: 'center',
  },
  label: {
    color: Colors.textSecondary,
    fontSize: FontSize.xs,
    fontWeight: '600',
  },
});
